const express = require('express');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const { checkAndEscalateTickets } = require('./services/escalationScheduler');
const { checkAndSendSlotReminders } = require('./services/slotReminderScheduler');

dotenv.config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Serve Uploads static directory
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/blood-requests', require('./routes/bloodRequests'));
app.use('/api/valid-students', require('./routes/validStudents'));
app.use('/api/departments', require('./routes/departments'));
app.use('/api/tickets', require('./routes/tickets'));
app.use('/api/availability', require('./routes/availability'));
app.use('/api/slots', require('./routes/slots'));
app.use('/api/doubts', require('./routes/doubts'));
app.use('/api/feedback', require('./routes/feedback'));
app.use('/api/mentor-diary', require('./routes/mentorDiary'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/early-warning', require('./routes/earlyWarning'));
app.use('/api/achievements', require('./routes/achievements'));
app.use('/api/announcements', require('./routes/announcements'));
app.use('/api/chat', require('./routes/chat'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/upload', require('./routes/upload'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'KIT College API Server is running clean.' });
});

// Serve static frontend in production
if (process.env.NODE_ENV === 'production' || true) {
  const distPath = path.join(__dirname, '../dist');
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api') && !req.path.startsWith('/uploads')) {
      res.sendFile(path.join(distPath, 'index.html'));
    }
  });
}

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  await connectDB();

  setInterval(() => {
    checkAndEscalateTickets();
  }, 10 * 60 * 1000);

  setInterval(() => {
    checkAndSendSlotReminders().catch(error => {
      console.error('Error sending slot reminders:', error);
    });
  }, 60 * 1000);

  app.listen(PORT, () => {
    console.log(`🚀 KIT College API Server running on port ${PORT}`);
  });
};

startServer().catch(error => {
  console.error(`API startup failed: ${error.message}`);
  process.exit(1);
});
