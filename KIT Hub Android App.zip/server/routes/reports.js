const express = require('express');
const router = express.Router();
const Department = require('../models/Department');
const Ticket = require('../models/Ticket');
const Availability = require('../models/Availability');
const Feedback = require('../models/Feedback');
const AcademicRecord = require('../models/AcademicRecord');
const User = require('../models/User');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');
const { generateHODReportPDF } = require('../services/pdfGenerator');
const { summarizeFeedbackThemes } = require('../services/aiService');

// @route   GET /api/reports/hod-pdf
// @desc    Generate Monthly HOD PDF Report
router.get('/hod-pdf', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    if (req.user.role === 'admin' && !req.user.department) {
      return res.status(403).json({ message: 'HOD account must belong to a department' });
    }
    const deptId = req.user.role === 'admin'
      ? (req.user.department?._id || req.user.department)
      : req.query.departmentId;
    let department = null;
    if (deptId) {
      department = await Department.findById(deptId).populate('hod');
      if (!department) return res.status(404).json({ message: 'Department not found' });
    }

    const deptName = department ? department.name : 'All Departments';
    const deptCode = department ? department.code : 'ALL';
    const hodName = department && department.hod ? department.hod.name : req.user.name;

    const filter = deptId ? { department: deptId } : {};

    // 1. Ticket metrics
    const totalTickets = await Ticket.countDocuments(filter);
    const approvedTickets = await Ticket.countDocuments({ ...filter, status: 'Approved' });
    const pendingTickets = await Ticket.countDocuments({ ...filter, status: 'Pending' });
    const escalatedTickets = await Ticket.countDocuments({ ...filter, status: 'Escalated' });

    // 2. Faculty availability
    const facultyList = await User.find({ ...filter, role: { $in: ['staff', 'admin'] } });
    const facultyIds = facultyList.map(f => f._id);
    const availabilities = await Availability.find({ faculty: { $in: facultyIds } }).populate('faculty', 'name');

    const facultyStats = facultyList.map(f => {
      const match = availabilities.find(a => a.faculty?._id?.toString() === f._id.toString());
      return {
        name: f.name,
        status: match ? match.status : 'Free',
        note: match ? match.note : ''
      };
    });

    // 3. Feedback metrics & AI summary
    const feedbacks = await Feedback.find(filter);
    const totalFeedback = feedbacks.length;
    const avgRating = totalFeedback > 0 ? (feedbacks.reduce((acc, f) => acc + (f.rating || 5), 0) / totalFeedback).toFixed(1) : '5.0';
    const stressedCount = feedbacks.filter(f => f.sentiment === 'Stressed/Negative').length;
    const aiSummary = await summarizeFeedbackThemes(feedbacks);

    // 4. Early Warning
    const academicRecords = await AcademicRecord.find({ ...filter, flagged: true }).populate({
      path: 'student',
      select: 'name registerNumber assignedMentor',
      populate: { path: 'assignedMentor', select: 'name' }
    });

    const flaggedStudents = academicRecords.map(r => ({
      name: r.student?.name || 'Student',
      registerNumber: r.student?.registerNumber || 'N/A',
      attendance: r.attendancePercentage,
      marks: r.marksPercentage,
      mentorName: r.student?.assignedMentor?.name || 'Unassigned'
    }));

    const reportData = {
      departmentName: deptName,
      departmentCode: deptCode,
      hodName,
      tickets: {
        total: totalTickets,
        approved: approvedTickets,
        pending: pendingTickets,
        escalated: escalatedTickets
      },
      facultyStats,
      feedback: {
        total: totalFeedback,
        avgRating,
        stressedCount,
        summary: aiSummary
      },
      earlyWarnings: {
        totalFlagged: flaggedStudents.length,
        students: flaggedStudents
      }
    };

    generateHODReportPDF(reportData, res);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
