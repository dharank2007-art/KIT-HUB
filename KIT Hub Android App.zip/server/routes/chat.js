const express = require('express');
const router = express.Router();
const ChatMessage = require('../models/ChatMessage');
const User = require('../models/User');
const { protect } = require('../middleware/authMiddleware');

const isAllowedConversation = (firstUser, secondUser) => {
  if (!firstUser || !secondUser || firstUser._id.toString() === secondUser._id.toString()) return false;
  return (firstUser.role === 'student' && ['admin', 'staff', 'super_admin'].includes(secondUser.role)) ||
    (secondUser.role === 'student' && ['admin', 'staff', 'super_admin'].includes(firstUser.role));
};

// @route   GET /api/chat/:userId
// @desc    Get chat conversation with specific user
router.get('/:userId', protect, async (req, res) => {
  try {
    const targetUserId = req.params.userId;
    const currentUserId = req.user._id;
    const targetUser = await User.findById(targetUserId).select('_id role department');
    if (!isAllowedConversation(req.user, targetUser)) {
      return res.status(403).json({ message: 'Messages are restricted to student and college staff conversations' });
    }
    if (req.user.role !== 'super_admin' && targetUser.role !== 'super_admin') {
      const ownDepartment = req.user.department?._id || req.user.department;
      const targetDepartment = targetUser.department?._id || targetUser.department;
      if (ownDepartment?.toString() !== targetDepartment?.toString()) {
        return res.status(403).json({ message: 'You may only message users in your department' });
      }
    }

    const messages = await ChatMessage.find({
      $or: [
        { sender: currentUserId, recipient: targetUserId },
        { sender: targetUserId, recipient: currentUserId }
      ]
    })
      .populate('sender', 'name role avatar')
      .populate('recipient', 'name role avatar')
      .sort({ createdAt: 1 });

    // Mark unread messages from target user as read
    await ChatMessage.updateMany(
      { sender: targetUserId, recipient: currentUserId, read: false },
      { read: true }
    );

    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/chat
// @desc    Send 1:1 chat message with attachments
router.post('/', protect, async (req, res) => {
  try {
    const { recipientId, message, attachments } = req.body;
    if (!recipientId) {
      return res.status(400).json({ message: 'Recipient ID is required' });
    }

    const recipient = await User.findById(recipientId).select('_id role department');
    if (!isAllowedConversation(req.user, recipient)) {
      return res.status(403).json({ message: 'Messages are restricted to student and college staff conversations' });
    }
    if (req.user.role !== 'super_admin' && recipient.role !== 'super_admin') {
      const ownDepartment = req.user.department?._id || req.user.department;
      const recipientDepartment = recipient.department?._id || recipient.department;
      if (ownDepartment?.toString() !== recipientDepartment?.toString()) {
        return res.status(403).json({ message: 'You may only message users in your department' });
      }
    }

    if (!message && (!attachments || attachments.length === 0)) {
      return res.status(400).json({ message: 'Message or attachment required' });
    }

    const newMsg = new ChatMessage({
      sender: req.user._id,
      recipient: recipientId,
      message: message || '',
      attachments: attachments || []
    });

    await newMsg.save();

    const populated = await ChatMessage.findById(newMsg._id)
      .populate('sender', 'name role avatar')
      .populate('recipient', 'name role avatar');

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
