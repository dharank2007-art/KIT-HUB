const express = require('express');
const router = express.Router();
const MentorDiary = require('../models/MentorDiary');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

// @route   GET /api/mentor-diary
// @desc    Get mentor diary entries (Student sees own, Mentor/HOD sees mentees)
router.get('/', protect, async (req, res) => {
  try {
    const { studentId } = req.query;
    let filter = {};

    if (req.user.role === 'student') {
      filter.student = req.user._id;
    } else if (req.user.role === 'staff') {
      filter.mentor = req.user._id;
      if (studentId) filter.student = studentId;
    } else if (req.user.role === 'admin') {
      const departmentId = req.user.department?._id || req.user.department;
      const students = await User.find({ department: departmentId, role: 'student' }).select('_id');
      filter.student = { $in: students.map(student => student._id) };
      if (studentId) filter.student = students.some(student => student._id.toString() === studentId) ? studentId : null;
    } else if (studentId) {
      filter.student = studentId;
    }

    const entries = await MentorDiary.find(filter)
      .populate('mentor', 'name email employeeId avatar')
      .populate('student', 'name email registerNumber avatar phone')
      .sort({ date: -1 });

    res.json(entries);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/mentor-diary
// @desc    Log meeting record in mentor diary (Mentor: Faculty/HOD)
router.post('/', protect, requireRole('staff', 'admin', 'super_admin'), async (req, res) => {
  try {
    const { studentId, date, topicsDiscussed, goals, mentorNotes, academicStatus, followUpDate } = req.body;

    if (!studentId || !topicsDiscussed) {
      return res.status(400).json({ message: 'Student ID and topics discussed are required' });
    }

    const student = await User.findOne({ _id: studentId, role: 'student' });
    if (!student) return res.status(404).json({ message: 'Student not found' });
    const mentorDepartment = req.user.department?._id || req.user.department;
    if (req.user.role !== 'super_admin' && student.department?.toString() !== mentorDepartment?.toString()) {
      return res.status(403).json({ message: 'Mentors may only record entries for students in their department' });
    }
    if (req.user.role === 'staff' && student.assignedMentor && student.assignedMentor.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'This student is assigned to another mentor' });
    }

    const entry = new MentorDiary({
      mentor: req.user._id,
      student: studentId,
      date: date || new Date(),
      topicsDiscussed,
      goals: goals || '',
      mentorNotes: mentorNotes || '',
      academicStatus: academicStatus || 'Satisfactory',
      followUpDate: followUpDate || null
    });

    await entry.save();

    // Create notification for student
    await Notification.create({
      user: studentId,
      title: 'New Mentor Meeting Entry',
      message: `Your mentor ${req.user.name} logged a new mentoring session note and goals.`,
      type: 'info',
      link: '/mentor-diary'
    });

    const populated = await MentorDiary.findById(entry._id)
      .populate('mentor', 'name email avatar')
      .populate('student', 'name email registerNumber');

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
