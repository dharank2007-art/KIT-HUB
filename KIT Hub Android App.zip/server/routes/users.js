const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Department = require('../models/Department');
const ValidStudent = require('../models/ValidStudent');
const Notification = require('../models/Notification');
const PDFDocument = require('pdfkit');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

router.get('/me/export', protect, async (req, res) => {
  try {
    const account = await User.findById(req.user._id).select('-password').populate('department', 'name code');
    if (!account) return res.status(404).json({ message: 'User not found' });
    const data = {
      name: account.name,
      email: account.email,
      role: account.role,
      registerNumber: account.registerNumber || '',
      department: account.department?.name || '',
      className: account.className || '',
      bloodGroup: account.bloodGroup || '',
      phone: account.phone || '',
      linkedin: account.linkedin || '',
      portfolio: account.portfolio || ''
    };
    const format = (req.query.format || 'json').toLowerCase();
    if (format === 'json') return res.json(data);
    if (format === 'csv') {
      const quote = value => `"${String(value).replace(/"/g, '""')}"`;
      const csv = [Object.keys(data), Object.values(data)].map(row => row.map(quote).join(',')).join('\r\n');
      res.type('text/csv').attachment('kit-hub-my-data.csv').send(csv);
      return;
    }
    if (format !== 'pdf') return res.status(400).json({ message: 'Format must be pdf, json, or csv' });

    res.type('application/pdf').attachment('kit-hub-my-data.pdf');
    const document = new PDFDocument({ margin: 48 });
    document.pipe(res);
    document.fontSize(20).text('KIT College App - Personal Data');
    document.moveDown();
    Object.entries(data).forEach(([key, value]) => {
      document.fontSize(11).fillColor('#475569').text(key.replace(/[A-Z]/g, letter => ` ${letter}`).toUpperCase());
      document.fontSize(13).fillColor('#0f172a').text(value || 'Not provided');
      document.moveDown(0.4);
    });
    document.end();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const isValidLinkedIn = (value) => {
  if (!value) return false;
  try {
    const url = new URL(value.startsWith('http') ? value : `https://${value}`);
    return url.protocol === 'https:' && ['linkedin.com', 'www.linkedin.com'].includes(url.hostname) && /^\/in\/[\w%-]+\/?$/.test(url.pathname);
  } catch {
    return false;
  }
};

router.get('/blood-donors', protect, async (req, res) => {
  try {
    const { bloodGroup, department } = req.query;
    const filter = { role: 'student', status: 'approved', _id: { $ne: req.user._id } };
    if (bloodGroup) filter.bloodGroup = bloodGroup;
    if (department) filter.department = department;
    const donors = await User.find(filter)
      .select('name registerNumber className bloodGroup department')
      .populate('department', 'name code')
      .sort({ name: 1 });
    res.json(donors);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/approvals', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const status = req.query.status || 'pending';
    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid approval status' });
    }
    const filter = { role: 'student', status };
    if (req.user.role === 'admin') filter.department = req.user.department?._id || req.user.department;
    const users = await User.find(filter).select('-password')
      .populate('department approvalReviewedBy', 'name code email')
      .sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.patch('/:id/approval', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const { status, note } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Approval status must be approved or rejected' });
    }
    const user = await User.findOne({ _id: req.params.id, role: 'student' });
    if (!user) return res.status(404).json({ message: 'Student registration not found' });
    const userDepartment = user.department?.toString();
    const reviewerDepartment = (req.user.department?._id || req.user.department)?.toString();
    if (req.user.role === 'admin' && userDepartment !== reviewerDepartment) {
      return res.status(403).json({ message: 'HODs may only review students in their department' });
    }
    user.status = status;
    user.approvalReviewedBy = req.user._id;
    user.approvalReviewedAt = new Date();
    user.approvalNote = note || '';
    await user.save();
    await Notification.create({
      user: user._id,
      title: `Registration ${status}`,
      message: status === 'approved' ? 'Your account is approved. You can now sign in.' : 'Your registration was rejected. Contact your department administrator.',
      type: 'info',
      link: '/login'
    });
    res.json({ message: `Student registration ${status}`, status: user.status });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete('/:id', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const user = await User.findOne({ _id: req.params.id, role: 'student' });
    if (!user) return res.status(404).json({ message: 'Student not found' });
    const userDepartment = user.department?.toString();
    const reviewerDepartment = (req.user.department?._id || req.user.department)?.toString();
    if (req.user.role === 'admin' && userDepartment !== reviewerDepartment) {
      return res.status(403).json({ message: 'HODs may only delete students in their department' });
    }
    await user.deleteOne();
    res.json({ message: 'Student account deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/users
// @desc    Get directory / users list with role & department filters
router.get('/', protect, async (req, res) => {
  try {
    const { role, department, search } = req.query;
    const filter = {};

    if (role) filter.role = role;
    filter.status = 'approved';
    
    // HOD sees users in their department unless super_admin
    if (req.user.role === 'admin') {
      filter.department = req.user.department?._id || req.user.department || null;
    } else if (department) {
      filter.department = department;
    }

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { registerNumber: { $regex: search, $options: 'i' } },
        { employeeId: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(filter)
      .select('-password')
      .populate('department assignedMentor');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/users
// @desc    Create single user (Super Admin or HOD)
router.post('/', protect, requireRole('super_admin', 'admin'), async (req, res) => {
  try {
    const { name, email, password, role, department, registerNumber, employeeId, designation, phone, assignedMentor } = req.body;

    if (!name || !email || !role) {
      return res.status(400).json({ message: 'Name, email and role are required' });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({ message: 'User with this email already exists' });
    }

    // Default initial password if not provided
    const userPassword = password || 'Welcome@123';

    // Role name enforcement: super_admin, admin, staff, student
    const validRoles = ['super_admin', 'admin', 'staff', 'student'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: `Invalid role. Must be one of: ${validRoles.join(', ')}` });
    }

    if (req.user.role === 'admin' && !['staff', 'student'].includes(role)) {
      return res.status(403).json({ message: 'HODs may only create faculty and student accounts' });
    }

    if (role === 'super_admin' && await User.exists({ role: 'super_admin' })) {
      return res.status(409).json({ message: 'A super admin account already exists' });
    }

    const departmentId = req.user.role === 'admin'
      ? (req.user.department?._id || req.user.department)
      : department;
    if (role !== 'super_admin' && !departmentId) {
      return res.status(400).json({ message: 'A department is required for this role' });
    }
    if (departmentId && !await Department.exists({ _id: departmentId })) {
      return res.status(400).json({ message: 'Department not found' });
    }
    let mentorId = null;
    if (assignedMentor) {
      if (role !== 'student') return res.status(400).json({ message: 'Only student accounts can be assigned a mentor' });
      const mentor = await User.findOne({ _id: assignedMentor, role: 'staff', department: departmentId });
      if (!mentor) return res.status(400).json({ message: 'Mentor must be faculty in the selected department' });
      mentorId = mentor._id;
    }

    const newUser = new User({
      name,
      email: email.toLowerCase(),
      password: userPassword,
      role,
      department: departmentId || null,
      registerNumber,
      employeeId,
      designation,
      phone,
      assignedMentor: mentorId,
      isPasswordChanged: false
    });

    await newUser.save();
    const populated = await User.findById(newUser._id).select('-password').populate('department assignedMentor');
    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/users/bulk-csv
// @desc    Bulk create faculty & students via CSV data (Super Admin)
router.post('/bulk-csv', protect, requireRole('super_admin'), async (req, res) => {
  try {
    const { rows } = req.body; // Array of { name, email, role, departmentCode, registerNumber, employeeId, phone, password }
    if (!rows || !Array.isArray(rows)) {
      return res.status(400).json({ message: 'Invalid data format. Expected an array of user rows.' });
    }

    const departments = await Department.find({});
    const deptMap = {};
    departments.forEach(d => {
      deptMap[d.code.toUpperCase()] = d._id;
      deptMap[d.name.toLowerCase()] = d._id;
    });

    const createdUsers = [];
    const errors = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      try {
        if (!row.name || !row.email || !row.role) {
          errors.push({ line: i + 1, error: 'Missing name, email, or role' });
          continue;
        }

        const existing = await User.findOne({ email: row.email.toLowerCase() });
        if (existing) {
          errors.push({ line: i + 1, email: row.email, error: 'User already exists' });
          continue;
        }

        const roleMap = {
          'faculty': 'staff',
          'staff': 'staff',
          'student': 'student'
        };
        const mappedRole = roleMap[row.role.toLowerCase().trim()];
        if (!mappedRole) {
          errors.push({ line: i + 2, email: row.email, error: 'Role must be faculty, staff, or student' });
          continue;
        }

        const departmentKey = (row.department || row.departmentCode || '').toString().trim();
        const deptId = deptMap[departmentKey.toUpperCase()] || deptMap[departmentKey.toLowerCase()];
        if (!deptId) {
          errors.push({ line: i + 2, email: row.email, error: 'A valid department code or name is required' });
          continue;
        }

        const newUser = new User({
          name: row.name.trim(),
          email: row.email.toLowerCase().trim(),
          password: row.password || 'Welcome@123',
          role: mappedRole,
          department: deptId,
          registerNumber: row.registerNumber || row.regNo || '',
          employeeId: row.employeeId || row.empId || '',
          designation: row.designation || '',
          phone: row.phone || '',
          isPasswordChanged: false
        });

        await newUser.save();
        createdUsers.push(newUser.email);
      } catch (err) {
        errors.push({ line: i + 1, email: row.email, error: err.message });
      }
    }

    res.json({
      message: `Successfully processed bulk upload. Created ${createdUsers.length} users.`,
      createdCount: createdUsers.length,
      createdUsers,
      errors
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/users/:id
// @desc    Update user details / avatar / mentor
router.put('/:id', protect, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const isSelf = req.user._id.toString() === req.params.id;
    if (!isSelf && !['super_admin', 'admin'].includes(req.user.role)) {
      return res.status(403).json({ message: 'Not authorized to update this user' });
    }
    const ownDepartment = req.user.department?._id || req.user.department;
    if (req.user.role === 'admin' && user.department?.toString() !== ownDepartment?.toString()) {
      return res.status(403).json({ message: 'HODs may only update users in their department' });
    }

    const { name, phone, avatar, department, assignedMentor, registerNumber, employeeId, className, bloodGroup, linkedin, portfolio } = req.body;
    if (name) user.name = name;
    if (req.body.designation !== undefined && ['super_admin', 'admin'].includes(req.user.role)) user.designation = req.body.designation;
    if (phone !== undefined) user.phone = phone;
    if (avatar !== undefined) user.avatar = avatar;
    if (req.user.role === 'student' && linkedin !== undefined && !isValidLinkedIn(linkedin)) {
      return res.status(400).json({ message: 'Enter a valid LinkedIn profile URL' });
    }
    if (linkedin !== undefined) user.linkedin = linkedin.trim();
    if (portfolio !== undefined) {
      if (portfolio && !/^https:\/\//i.test(portfolio)) return res.status(400).json({ message: 'Portfolio must be a valid HTTPS URL' });
      user.portfolio = portfolio.trim();
    }
    if (bloodGroup !== undefined) {
      if (user.role === 'student' && !['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].includes(bloodGroup)) {
        return res.status(400).json({ message: 'Select a valid blood group' });
      }
      user.bloodGroup = bloodGroup;
    }
    if (className !== undefined && user.role === 'student') user.className = className.trim();
    if (department && req.user.role === 'super_admin') user.department = department;
    if (assignedMentor !== undefined && user.role !== 'student') {
      return res.status(400).json({ message: 'Only student accounts can be assigned a mentor' });
    }
    if (assignedMentor !== undefined && !isSelf && ['super_admin', 'admin'].includes(req.user.role)) {
      const mentor = await User.findOne({ _id: assignedMentor, role: 'staff', department: user.department });
      if (!mentor) return res.status(400).json({ message: 'Mentor must be faculty in the student department' });
      user.assignedMentor = assignedMentor;
    }
    if (registerNumber !== undefined) user.registerNumber = registerNumber;
    if (employeeId !== undefined) user.employeeId = employeeId;

    await user.save();
    const updated = await User.findById(user._id).select('-password').populate('department assignedMentor');
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
