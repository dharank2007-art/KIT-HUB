const express = require('express');
const router = express.Router();
const Ticket = require('../models/Ticket');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');
const { checkAndEscalateTickets } = require('../services/escalationScheduler');

// @route   GET /api/tickets
// @desc    Get tickets with role-based scoping
router.get('/', protect, async (req, res) => {
  try {
    const { status, type } = req.query;
    let filter = {};

    if (status) filter.status = status;
    if (type) filter.type = type;

    if (req.user.role === 'student') {
      // Student sees only own tickets
      filter.student = req.user._id;
    } else if (req.user.role === 'staff') {
      filter.assignedTo = req.user._id;
    } else if (req.user.role === 'admin') {
      // HOD sees all tickets in their department
      filter.department = req.user.department?._id || req.user.department || null;
    }
    // super_admin sees all tickets (filter is empty by default unless query params provided)

    const tickets = await Ticket.find(filter)
      .populate('student', 'name email registerNumber avatar')
      .populate('department', 'name code')
      .populate('assignedTo', 'name email role')
      .populate('timeline.updatedBy', 'name role')
      .sort({ updatedAt: -1 });

    res.json(tickets);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/tickets
// @desc    Create new ticket (Students or Faculty)
router.post('/', protect, async (req, res) => {
  try {
    const { title, description, type, attachments } = req.body;

    if (!title || !description || !type) {
      return res.status(400).json({ message: 'Title, description, and type are required' });
    }
    if (!['Leave', 'OD', 'Bonafide', 'Doubt', 'Complaint'].includes(type)) {
      return res.status(400).json({ message: 'Invalid ticket type' });
    }

    const deptId = req.user.department?._id || req.user.department;
    if (!deptId && req.user.role !== 'super_admin') {
      return res.status(400).json({ message: 'User must belong to a department to raise tickets' });
    }

    // Default assignedTo: assigned mentor or department HOD if available
    let assignee = req.user.assignedMentor;
    if (assignee) {
      const mentor = await User.findOne({ _id: assignee, role: 'staff', department: deptId });
      assignee = mentor?._id;
    }
    if (!assignee && deptId) {
      const faculty = await User.findOne({ department: deptId, role: 'staff' });
      if (faculty) assignee = faculty._id;
    }
    if (!assignee && deptId) {
      const hod = await User.findOne({ department: deptId, role: 'admin' });
      if (hod) assignee = hod._id;
    }

    const ticket = new Ticket({
      title,
      description,
      type,
      student: req.user._id,
      department: deptId,
      assignedTo: assignee,
      attachments: attachments || [],
      timeline: [{
        status: 'Pending',
        updatedBy: req.user._id,
        comment: 'Ticket created',
        timestamp: new Date()
      }]
    });

    await ticket.save();

    // Notify assignee
    if (assignee) {
      await Notification.create({
        user: assignee,
        title: `New Ticket: ${type}`,
        message: `${req.user.name} submitted a ${type} ticket: "${title}"`,
        type: 'ticket',
        link: '/tickets'
      });
    }

    const populated = await Ticket.findById(ticket._id)
      .populate('student', 'name email registerNumber')
      .populate('department', 'name code')
      .populate('assignedTo', 'name email role');

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/tickets/:id/status
// @desc    Update ticket status (Approve / Reject / Escalate)
router.put('/:id/status', protect, requireRole('staff', 'admin', 'super_admin'), async (req, res) => {
  try {
    const { status, comment } = req.body;
    const ticket = await Ticket.findById(req.params.id).populate('student department');

    if (!ticket) {
      return res.status(404).json({ message: 'Ticket not found' });
    }

    if (!['Pending', 'Approved', 'Rejected', 'Escalated'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    const departmentId = ticket.department?._id?.toString() || ticket.department?.toString();
    if (req.user.role === 'staff' && ticket.assignedTo?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Faculty may only act on tickets assigned to them' });
    }
    if (req.user.role === 'admin' && departmentId !== req.user.department?._id?.toString() && departmentId !== req.user.department?.toString()) {
      return res.status(403).json({ message: 'HODs may only act on tickets in their department' });
    }
    if (['Approved', 'Rejected'].includes(ticket.status)) {
      return res.status(400).json({ message: 'A finalized ticket cannot be changed' });
    }
    if (status === 'Escalated' && ticket.escalationLevel >= 2) {
      return res.status(400).json({ message: 'Ticket has reached the final escalation level' });
    }

    ticket.status = status;
    ticket.updatedAt = new Date();
    ticket.timeline.push({
      status,
      updatedBy: req.user._id,
      comment: comment || `Status updated to ${status}`,
      timestamp: new Date()
    });

    if (status === 'Escalated') {
      ticket.escalationLevel = Math.min(ticket.escalationLevel + 1, 2);
      ticket.lastEscalatedAt = new Date();
      const nextRole = ticket.escalationLevel === 1 ? 'admin' : 'super_admin';
      const nextAssignee = nextRole === 'admin'
        ? await User.findOne({ department: ticket.department._id, role: nextRole })
        : await User.findOne({ role: nextRole });
      if (nextAssignee) ticket.assignedTo = nextAssignee._id;
    }

    await ticket.save();

    // Notify student
    await Notification.create({
      user: ticket.student._id,
      title: `Ticket Status Update: ${ticket.title}`,
      message: `Your ticket "${ticket.title}" status changed to ${status}.`,
      type: 'ticket',
      link: '/tickets'
    });
    if (status === 'Escalated' && ticket.assignedTo) {
      await Notification.create({
        user: ticket.assignedTo,
        title: 'Ticket Escalated to You',
        message: `Ticket "${ticket.title}" requires your review.`,
        type: 'ticket',
        link: '/tickets'
      });
    }

    const updated = await Ticket.findById(ticket._id)
      .populate('student', 'name email registerNumber')
      .populate('department', 'name code')
      .populate('assignedTo', 'name email role')
      .populate('timeline.updatedBy', 'name role');

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/tickets/run-escalation
// @desc    Trigger auto-escalation check on demand (for testing SLA)
router.post('/run-escalation', protect, requireRole('super_admin'), async (req, res) => {
  try {
    await checkAndEscalateTickets();
    res.json({ message: 'Auto-escalation check completed successfully.' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
