const express = require('express');
const router = express.Router();
const ValidStudent = require('../models/ValidStudent');
const Department = require('../models/Department');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

router.get('/', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === 'admin') filter.department = req.user.department?._id || req.user.department;
    const entries = await ValidStudent.find(filter).populate('department', 'name code').sort({ registerNumber: 1 });
    res.json(entries);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/bulk-csv', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const { rows } = req.body;
    if (!Array.isArray(rows)) return res.status(400).json({ message: 'Expected an array of roster rows' });

    const departments = await Department.find({});
    const departmentMap = new Map();
    departments.forEach(department => {
      departmentMap.set(department.code.toUpperCase(), department._id);
      departmentMap.set(department.name.toLowerCase(), department._id);
    });
    const ownDepartmentId = req.user.department?._id || req.user.department;
    const imported = [];
    const errors = [];

    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index] || {};
      const registerNumber = (row.registerNumber || row.rollNo || '').trim().toUpperCase();
      const className = (row.className || row.class || '').trim();
      const departmentKey = (row.department || row.departmentCode || '').trim();
      const departmentId = req.user.role === 'admin'
        ? ownDepartmentId
        : (departmentMap.get(departmentKey.toUpperCase()) || departmentMap.get(departmentKey.toLowerCase()));

      if (!registerNumber || !className || !departmentId) {
        errors.push({ line: index + 2, registerNumber, error: 'Roll number, class, and valid department are required' });
        continue;
      }

      try {
        const entry = await ValidStudent.findOneAndUpdate(
          { registerNumber },
          { registerNumber, className, department: departmentId },
          { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
        );
        imported.push(entry.registerNumber);
      } catch (error) {
        errors.push({ line: index + 2, registerNumber, error: error.message });
      }
    }

    res.json({ importedCount: imported.length, imported, errors });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete('/:id', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    const entry = await ValidStudent.findById(req.params.id);
    if (!entry) return res.status(404).json({ message: 'Roster entry not found' });
    const ownDepartmentId = (req.user.department?._id || req.user.department)?.toString();
    if (req.user.role === 'admin' && entry.department.toString() !== ownDepartmentId) {
      return res.status(403).json({ message: 'HODs may only manage their department roster' });
    }
    await entry.deleteOne();
    res.json({ message: 'Roster entry removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;