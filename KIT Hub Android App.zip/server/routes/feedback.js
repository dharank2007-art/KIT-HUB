const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedback');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');
const { analyzeSentiment } = require('../services/sentimentAnalyzer');
const { summarizeFeedbackThemes } = require('../services/aiService');

// @route   GET /api/feedback
// @desc    Get feedback list (HOD sees department, Super Admin sees all)
router.get('/', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    let filter = {};
    if (req.user.role === 'admin') {
      filter.department = req.user.department?._id || req.user.department || null;
    }

    const feedbacks = await Feedback.find(filter)
      .populate('targetUser', 'name role employeeId avatar')
      .populate('department', 'name code')
      .sort({ createdAt: -1 });

    res.json(feedbacks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/feedback
// @desc    Submit ANONYMOUS feedback (Stores NO user ID!)
router.post('/', protect, async (req, res) => {
  try {
    const { targetUserId, departmentId, category, content, rating } = req.body;

    if (!content) {
      return res.status(400).json({ message: 'Feedback content is required' });
    }

    const department = req.user.role === 'admin'
      ? (req.user.department?._id || req.user.department)
      : (req.user.role === 'super_admin' ? departmentId : (req.user.department?._id || req.user.department));
    if (!department) {
      return res.status(400).json({ message: 'A department is required for this feedback' });
    }
    if (targetUserId) {
      const target = await require('../models/User').findOne({
        _id: targetUserId,
        role: { $in: ['staff', 'admin'] },
        department
      });
      if (!target) return res.status(400).json({ message: 'Target faculty or HOD must belong to the selected department' });
    }
    if (category && !['Teaching', 'Infrastructure', 'Behaviour', 'General'].includes(category)) {
      return res.status(400).json({ message: 'Invalid feedback category' });
    }
    if (rating !== undefined && (Number(rating) < 1 || Number(rating) > 5)) {
      return res.status(400).json({ message: 'Rating must be between 1 and 5' });
    }

    // Run automatic sentiment analysis
    const sentimentAnalysis = analyzeSentiment(content);

    // Create feedback record WITHOUT ANY USER ID
    const feedback = new Feedback({
      targetUser: targetUserId || null,
      department,
      category: category || 'General',
      content,
      rating: rating || 5,
      sentiment: sentimentAnalysis.category,
      sentimentScore: sentimentAnalysis.score
    });

    await feedback.save();

    res.status(201).json({ 
      message: 'Anonymous feedback submitted successfully. Thank you!',
      sentimentFlagged: feedback.sentiment === 'Stressed/Negative'
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/feedback/summary
// @desc    AI-summarized themes for HOD/Super Admin
router.get('/summary', protect, requireRole('admin', 'super_admin'), async (req, res) => {
  try {
    let filter = {};
    if (req.user.role === 'admin') {
      filter.department = req.user.department?._id || req.user.department || null;
    }

    const feedbacks = await Feedback.find(filter);
    const summary = await summarizeFeedbackThemes(feedbacks);

    res.json({ summary });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
