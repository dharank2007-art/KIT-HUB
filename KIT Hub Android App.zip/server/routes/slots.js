const express = require('express');
const router = express.Router();
const Slot = require('../models/Slot');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');
const { timeToMinutes, isTenMinuteRange } = require('../utils/slotTime');

// @route   GET /api/slots
// @desc    Get available or published slots (filtered by faculty or date)
router.get('/', protect, async (req, res) => {
  try {
    const { facultyId, date } = req.query;
    let filter = { isCancelled: false };

    if (facultyId) filter.faculty = facultyId;
    if (date) filter.date = date;

    const slots = await Slot.find(filter)
      .populate('faculty', 'name email role department avatar')
      .populate('bookings.student', 'name email registerNumber phone')
      .sort({ date: 1, startTime: 1 });

    res.json(slots);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/slots
// @desc    Publish 10-minute meeting slot (Faculty/HOD)
router.post('/', protect, requireRole('staff', 'admin'), async (req, res) => {
  try {
    const { date, startTime, endTime, location, maxStudents, notes } = req.body;

    if (!date || !startTime || !endTime) {
      return res.status(400).json({ message: 'Date, start time, and end time are required' });
    }

    const startMinutes = timeToMinutes(startTime);
    const endMinutes = timeToMinutes(endTime);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !isTenMinuteRange(startTime, endTime)) {
      return res.status(400).json({ message: 'Slots must use a valid date and exactly 10-minute duration' });
    }
    const [year, month, day] = date.split('-').map(Number);
    const startsAt = new Date(year, month - 1, day, Math.floor(startMinutes / 60), startMinutes % 60);
    if (startsAt <= new Date()) {
      return res.status(400).json({ message: 'A slot must start in the future' });
    }

    const sameDaySlots = await Slot.find({ faculty: req.user._id, date, isCancelled: false });
    const overlaps = sameDaySlots.some((slot) => {
      const existingStart = timeToMinutes(slot.startTime);
      const existingEnd = timeToMinutes(slot.endTime);
      return existingStart !== null && existingEnd !== null && startMinutes < existingEnd && endMinutes > existingStart;
    });
    if (overlaps) return res.status(409).json({ message: 'This slot overlaps another published slot' });

    const newSlot = new Slot({
      faculty: req.user._id,
      date,
      startTime,
      endTime,
      location: location || 'Faculty Cabin',
      maxStudents: 1,
      notes: notes || '',
      bookings: []
    });

    await newSlot.save();

    const populated = await Slot.findById(newSlot._id)
      .populate('faculty', 'name email role department avatar');

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/slots/:id/book
// @desc    Book a slot (Student)
router.post('/:id/book', protect, requireRole('student'), async (req, res) => {
  try {
    const { reason } = req.body;
    const slot = await Slot.findById(req.params.id).populate('faculty');

    if (!slot || slot.isCancelled) {
      return res.status(404).json({ message: 'Slot not found or cancelled' });
    }

    // Check if slot is already fully booked
    const activeBookings = slot.bookings.filter(b => b.status === 'Booked');
    if (activeBookings.length >= slot.maxStudents) {
      return res.status(400).json({ message: 'Slot is fully booked' });
    }

    // Check if student already booked this slot
    const existing = slot.bookings.find(b => b.student.toString() === req.user._id.toString() && b.status === 'Booked');
    if (existing) {
      return res.status(400).json({ message: 'You have already booked this slot' });
    }

    slot.bookings.push({
      student: req.user._id,
      reason: reason || 'Academic Consultation',
      status: 'Booked',
      bookedAt: new Date()
    });

    await slot.save();

    // Create notification for faculty
    await Notification.create({
      user: slot.faculty._id,
      title: 'Slot Booked Alert',
      message: `Student ${req.user.name} booked a slot with you on ${slot.date} at ${slot.startTime}.`,
      type: 'slot',
      link: '/slots'
    });

    // Create notification reminder for student
    await Notification.create({
      user: req.user._id,
      title: 'Slot Booking Confirmed',
      message: `Your appointment with ${slot.faculty.name} is confirmed for ${slot.date} at ${slot.startTime} (${slot.location}).`,
      type: 'slot',
      link: '/slots'
    });

    const updated = await Slot.findById(slot._id)
      .populate('faculty', 'name email role department avatar')
      .populate('bookings.student', 'name email registerNumber phone');

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/slots/:id/cancel
// @desc    Cancel slot booking or full slot
router.post('/:id/cancel', protect, async (req, res) => {
  try {
    const slot = await Slot.findById(req.params.id).populate('faculty');
    if (!slot) return res.status(404).json({ message: 'Slot not found' });

    if (req.user.role === 'student') {
      // Student cancels own booking
      const booking = slot.bookings.find(b => b.student.toString() === req.user._id.toString() && b.status === 'Booked');
      if (booking) {
        booking.status = 'Cancelled';
        await slot.save();

        await Notification.create({
          user: slot.faculty._id,
          title: 'Slot Booking Cancelled',
          message: `Student ${req.user.name} cancelled their slot on ${slot.date} at ${slot.startTime}.`,
          type: 'slot',
          link: '/slots'
        });
      }
    } else if (['staff', 'admin', 'super_admin'].includes(req.user.role)) {
      const facultyDepartment = slot.faculty.department?._id?.toString() || slot.faculty.department?.toString();
      const userDepartment = req.user.department?._id?.toString() || req.user.department?.toString();
      if (req.user.role === 'staff' && slot.faculty._id.toString() !== req.user._id.toString()) {
        return res.status(403).json({ message: 'Faculty may only cancel their own slots' });
      }
      if (req.user.role === 'admin' && facultyDepartment !== userDepartment) {
        return res.status(403).json({ message: 'HODs may only cancel slots in their department' });
      }
      // Faculty cancels entire slot
      slot.isCancelled = true;
      await slot.save();

      // Notify all booked students
      for (let b of slot.bookings) {
        if (b.status === 'Booked') {
          await Notification.create({
            user: b.student,
            title: 'Faculty Slot Cancelled',
            message: `Faculty ${req.user.name} cancelled the slot on ${slot.date} at ${slot.startTime}.`,
            type: 'slot',
            link: '/slots'
          });
        }
      }
    } else {
      return res.status(403).json({ message: 'Not authorized to cancel this slot' });
    }

    res.json({ message: 'Slot update/cancellation successful' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
