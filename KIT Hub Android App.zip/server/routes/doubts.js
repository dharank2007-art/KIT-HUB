const express = require('express');
const router = express.Router();
const Doubt = require('../models/Doubt');
const { protect } = require('../middleware/authMiddleware');

const hideAnonymousAuthor = (doubt) => {
  const doc = doubt.toObject ? doubt.toObject() : doubt;
  if (doc.isAnonymous) doc.author = { name: 'Anonymous Student', role: 'student', avatar: '' };
  return doc;
};

// @route   GET /api/doubts
// @desc    Get all doubts with search and filter
router.get('/', protect, async (req, res) => {
  try {
    const { search, department, resolved, tag } = req.query;
    let filter = {};

    if (department) filter.department = department;
    if (resolved !== undefined) filter.isResolved = resolved === 'true';
    if (tag) filter.tags = tag;

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } }
      ];
    }

    const doubts = await Doubt.find(filter)
      .populate('author', 'name role avatar department')
      .populate('department', 'name code')
      .populate('answers.author', 'name role avatar department')
      .sort({ createdAt: -1 });

    // Anonymize author if isAnonymous
    const sanitized = doubts.map(hideAnonymousAuthor);

    res.json(sanitized);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/doubts
// @desc    Post a new doubt (openly or anonymously)
router.post('/', protect, async (req, res) => {
  try {
    const { title, content, isAnonymous, tags, attachments } = req.body;
    if (!title || !content) {
      return res.status(400).json({ message: 'Title and content are required' });
    }

    const deptId = req.user.department?._id || req.user.department;

    const doubt = new Doubt({
      title,
      content,
      author: req.user._id,
      isAnonymous: !!isAnonymous,
      department: deptId,
      tags: tags || [],
      attachments: attachments || []
    });

    await doubt.save();

    const populated = await Doubt.findById(doubt._id)
      .populate('author', 'name role avatar')
      .populate('department', 'name code');

    res.status(201).json(hideAnonymousAuthor(populated));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/doubts/:id/upvote
// @desc    Upvote a doubt
router.post('/:id/upvote', protect, async (req, res) => {
  try {
    const doubt = await Doubt.findById(req.params.id);
    if (!doubt) return res.status(404).json({ message: 'Doubt not found' });

    const index = doubt.upvotes.indexOf(req.user._id);
    if (index === -1) {
      doubt.upvotes.push(req.user._id);
    } else {
      doubt.upvotes.splice(index, 1);
    }

    await doubt.save();
    res.json({ upvotesCount: doubt.upvotes.length, upvoted: index === -1 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/doubts/:id/answers
// @desc    Answer a doubt (Faculty or Student)
router.post('/:id/answers', protect, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ message: 'Answer content is required' });

    const doubt = await Doubt.findById(req.params.id);
    if (!doubt) return res.status(404).json({ message: 'Doubt not found' });

    const isFaculty = ['staff', 'admin'].includes(req.user.role);

    doubt.answers.push({
      author: req.user._id,
      isFaculty,
      content,
      createdAt: new Date()
    });

    await doubt.save();

    const updated = await Doubt.findById(doubt._id)
      .populate('author', 'name role avatar')
      .populate('department', 'name code')
      .populate('answers.author', 'name role avatar');

    res.json(hideAnonymousAuthor(updated));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/doubts/:id/resolve
// @desc    Mark doubt as resolved
router.put('/:id/resolve', protect, async (req, res) => {
  try {
    const doubt = await Doubt.findById(req.params.id);
    if (!doubt) return res.status(404).json({ message: 'Doubt not found' });

    // Allow author or faculty to mark resolved
    const sameDepartment = doubt.department?.toString() === (req.user.department?._id || req.user.department)?.toString();
    const canModerate = req.user.role === 'super_admin' || (sameDepartment && ['staff', 'admin'].includes(req.user.role));
    if (doubt.author.toString() !== req.user._id.toString() && !canModerate) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    doubt.isResolved = !doubt.isResolved;
    await doubt.save();

    res.json({ isResolved: doubt.isResolved });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
