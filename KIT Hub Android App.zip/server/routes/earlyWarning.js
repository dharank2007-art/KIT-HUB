const express = require('express');
const router = express.Router();
const AcademicRecord = require('../models/AcademicRecord');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

// @route   GET /api/early-warning
// @desc    Get academic records & flagged low performers
router.get('/', protect, async (req, res) => {
  try {
    const { flaggedOnly, department, semester } = req.query;
    let filter = {};

    if (flaggedOnly === 'true') filter.flagged = true;
    if (semester) filter.semester = semester;

    if (req.user.role === 'student') {
      filter.student = req.user._id;
    } else if (req.user.role === 'admin') {
      filter.department = req.user.department?._id || req.user.department || null;
    } else if (req.user.role === 'staff') {
      const mentees = await User.find({ assignedMentor: req.user._id, role: 'student' }).select('_id');
      filter.student = { $in: mentees.map(student => student._id) };
    } else if (department) {
      filter.department = department;
    }

    let query = AcademicRecord.find(filter)
      .populate({
        path: 'student',
        select: 'name email registerNumber phone avatar assignedMentor',
        populate: { path: 'assignedMentor', select: 'name email phone' }
      })
      .populate('department', 'name code')
      .sort({ flagged: -1, attendancePercentage: 1 });

    const records = await query;

    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/early-warning
// @desc    Add or update academic record (Manual entry by Faculty/HOD)
router.post('/', protect, requireRole('staff', 'admin', 'super_admin'), async (req, res) => {
  try {
    const { studentId, semester, subject, attendancePercentage, marksPercentage, remarks } = req.body;

    if (!studentId || !semester || !subject) {
      return res.status(400).json({ message: 'Student, semester, and subject are required' });
    }

    const student = await User.findOne({ _id: studentId, role: 'student' });
    if (!student) return res.status(404).json({ message: 'Student not found' });
    const attendance = Number(attendancePercentage);
    const marks = Number(marksPercentage);
    if (!Number.isFinite(attendance) || attendance < 0 || attendance > 100 || !Number.isFinite(marks) || marks < 0 || marks > 100) {
      return res.status(400).json({ message: 'Attendance and marks must be percentages between 0 and 100' });
    }
    const userDepartment = req.user.department?._id || req.user.department;
    if (req.user.role === 'admin' && student.department?.toString() !== userDepartment?.toString()) {
      return res.status(403).json({ message: 'HODs may only manage students in their department' });
    }
    if (req.user.role === 'staff' && student.assignedMentor?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Faculty may only manage their assigned mentees' });
    }

    let record = await AcademicRecord.findOne({ student: studentId, semester, subject });

    if (!record) {
      record = new AcademicRecord({
        student: studentId,
        department: student.department,
        semester,
        subject,
        attendancePercentage: attendance,
        marksPercentage: marks,
        remarks: remarks || ''
      });
    } else {
      record.attendancePercentage = attendance;
      record.marksPercentage = marks;
      record.remarks = remarks || '';
      record.updatedAt = new Date();
    }

    await record.save();

    // If flagged, send notification to assigned mentor & student
    if (record.flagged) {
      if (student.assignedMentor) {
        await Notification.create({
          user: student.assignedMentor,
          title: 'Early Warning Alert',
          message: `Mentee ${student.name} flagged for low performance in ${subject} (Att: ${attendancePercentage}%, Marks: ${marksPercentage}%).`,
          type: 'warning',
          link: '/early-warning'
        });
      }

      await Notification.create({
        user: student._id,
        title: 'Academic Alert',
        message: `Your academic performance in ${subject} needs attention (Attendance: ${attendancePercentage}%, Marks: ${marksPercentage}%).`,
        type: 'warning',
        link: '/early-warning'
      });
    }

    const populated = await AcademicRecord.findById(record._id)
      .populate('student', 'name registerNumber email')
      .populate('department', 'name code');

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/early-warning/bulk-csv
// @desc    Bulk upload attendance & marks via CSV
router.post('/bulk-csv', protect, requireRole('staff', 'admin', 'super_admin'), async (req, res) => {
  try {
    const { rows } = req.body; // Array of { registerNumber, semester, subject, attendancePercentage, marksPercentage, remarks }
    if (!rows || !Array.isArray(rows)) {
      return res.status(400).json({ message: 'Expected an array of record rows' });
    }

    const created = [];
    const errors = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      try {
        const regNo = row.registerNumber || row.regNo || row.studentId;
        const student = await User.findOne({ registerNumber: regNo, role: 'student' });

        if (!student) {
          errors.push({ line: i + 2, regNo, error: 'Student with register number not found' });
          continue;
        }

        const userDepartment = req.user.department?._id || req.user.department;
        if (req.user.role === 'admin' && student.department?.toString() !== userDepartment?.toString()) {
          errors.push({ line: i + 2, regNo, error: 'Student is outside your department' });
          continue;
        }
        if (req.user.role === 'staff' && student.assignedMentor?.toString() !== req.user._id.toString()) {
          errors.push({ line: i + 2, regNo, error: 'Student is not assigned to you as a mentee' });
          continue;
        }

        const attendance = Number(row.attendancePercentage ?? row.attendance);
        const marks = Number(row.marksPercentage ?? row.marks);
        if (!Number.isFinite(attendance) || attendance < 0 || attendance > 100 || !Number.isFinite(marks) || marks < 0 || marks > 100) {
          errors.push({ line: i + 2, regNo, error: 'Attendance and marks must be percentages between 0 and 100' });
          continue;
        }

        let record = await AcademicRecord.findOne({
          student: student._id,
          semester: row.semester || 'Sem 1',
          subject: row.subject || 'General'
        });

        if (!record) {
          record = new AcademicRecord({
            student: student._id,
            department: student.department,
            semester: row.semester || 'Sem 1',
            subject: row.subject || 'General',
            attendancePercentage: attendance,
            marksPercentage: marks,
            remarks: row.remarks || ''
          });
        } else {
          record.attendancePercentage = attendance;
          record.marksPercentage = marks;
          record.remarks = row.remarks || '';
        }

        await record.save();
        created.push(student.registerNumber);
      } catch (err) {
        errors.push({ line: i + 1, error: err.message });
      }
    }

    res.json({
      message: `Processed CSV. Imported ${created.length} academic records.`,
      importedCount: created.length,
      errors
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
