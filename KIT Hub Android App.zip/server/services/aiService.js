const FAQ = require('../models/FAQ');
const User = require('../models/User');

let Anthropic;
try {
  Anthropic = require('@anthropic-ai/sdk');
} catch (e) {
  Anthropic = null;
}

const getAIResponse = async (query, userContext = {}) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const isKeyValid = apiKey && apiKey !== 'your_anthropic_claude_api_key_here' && apiKey.startsWith('sk-');

  // Load relevant FAQs from DB
  const faqs = await FAQ.find({});
  const faqContextStr = faqs.map(f => `Q: ${f.question}\nA: ${f.answer}`).join('\n---\n');

  // Load faculty list for routing
  const userDepartment = userContext.department?._id || userContext.department;
  const facultyFilter = { role: { $in: ['staff', 'admin'] } };
  if (userContext.role !== 'super_admin' && userDepartment) facultyFilter.department = userDepartment;
  const facultyList = await User.find(facultyFilter).select('name email role').populate('department', 'name code');
  const facultyContextStr = facultyList.map(f => `${f.name} (${f.role === 'admin' ? 'HOD' : 'Faculty'}, Dept: ${f.department?.name || 'N/A'}, Email: ${f.email})`).join('\n');

  if (isKeyValid && Anthropic) {
    try {
      const anthropic = new Anthropic({ apiKey });
      const prompt = `You are the official AI Assistant for KIT College App.
Answer student and faculty queries accurately, warmly, and concisely.

Context FAQs:
${faqContextStr}

Available Faculty & HODs:
${facultyContextStr}

User Query: "${query}"

Guidelines:
1. If asking about OD (On Duty) or Leave steps: Explain that Leave/OD must be submitted under "Tickets" -> "Create Request Ticket" -> select Leave/OD, attach proof if any, and wait for Faculty/HOD approval.
2. If asking about a specific subject/issue, suggest the right faculty member from the list above.
3. Keep answers clear, encouraging, and helpful.`;

      const response = await anthropic.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      });

      if (response.content && response.content[0]?.text) {
        return {
          answer: response.content[0].text,
          source: 'Claude AI API'
        };
      }
    } catch (err) {
      console.warn('Anthropic API Call error, falling back to local NLP engine:', err.message);
    }
  }

  // Fallback intelligent responder engine
  const qLower = query.toLowerCase();

  // Match FAQs first
  const matchedFaq = faqs.find(f => qLower.includes(f.question.toLowerCase()) || f.question.toLowerCase().includes(qLower));
  if (matchedFaq) {
    return {
      answer: matchedFaq.answer,
      source: 'College FAQ Database'
    };
  }

  if (qLower.includes('leave') || qLower.includes('od') || qLower.includes('on duty') || qLower.includes('bonafide')) {
    return {
      answer: `📋 **Steps to Request Leave / OD / Bonafide Certificate at KIT College:**\n\n` +
        `1. Navigate to **Request Tickets** from the sidebar menu.\n` +
        `2. Click **+ New Ticket**.\n` +
        `3. Select the Type: **Leave**, **OD**, or **Bonafide**.\n` +
        `4. Fill in the reason, date range, and attach supporting docs/event proof.\n` +
        `5. Submit! Your request will be routed to your assigned Faculty/HOD.\n` +
        `6. *Note*: Requests auto-escalate to HOD after 48h if unaddressed!`,
      source: 'KIT Academic Rules Engine'
    };
  }

  if (qLower.includes('faculty') || qLower.includes('hod') || qLower.includes('contact') || qLower.includes('mentor') || qLower.includes('teacher')) {
    const list = facultyList.slice(0, 5).map(f => `• **${f.name}** (${f.department?.code || 'Dept'}): ${f.email}`).join('\n');
    return {
      answer: `🎓 **Available Faculty & Department Contacts:**\n\n${list}\n\nYou can also check real-time cabin availability or book a 10-minute slot under the **Faculty Availability** menu!`,
      source: 'Faculty Directory Engine'
    };
  }

  if (qLower.includes('exam') || qLower.includes('marks') || qLower.includes('attendance')) {
    return {
      answer: `📊 **Attendance & Marks Information:**\n\n` +
        `• Minimum attendance required is **75%**.\n` +
        `• Minimum passing mark is **50%**.\n` +
        `• Check your status under **Early Warning / Academic Dashboard** or consult your assigned Mentor.`,
      source: 'Academic Regulations'
    };
  }

  return {
    answer: `🤖 Welcome to KIT College AI Assistant!\n\nI can help you with:\n• How to apply for **Leave / OD / Bonafide**\n• Finding and contacting **Faculty / HODs**\n• Booking **10-minute faculty meeting slots**\n• College **FAQs & Regulations**\n\nPlease feel free to ask your specific question or check our FAQs!`,
    source: 'KIT AI Assistant'
  };
};

const summarizeFeedbackThemes = async (feedbackList) => {
  if (!feedbackList || feedbackList.length === 0) {
    return 'No feedback entries available yet for summary.';
  }

  const textBatch = feedbackList.map(f => `Category: ${f.category} | Rating: ${f.rating}/5 | Sentiment: ${f.sentiment} | Content: ${f.content}`).join('\n');

  const apiKey = process.env.ANTHROPIC_API_KEY;
  const isKeyValid = apiKey && apiKey !== 'your_anthropic_claude_api_key_here' && apiKey.startsWith('sk-');

  if (isKeyValid && Anthropic) {
    try {
      const anthropic = new Anthropic({ apiKey });
      const response = await anthropic.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 400,
        messages: [{
          role: 'user',
          content: `Analyze the following anonymous student feedback batch and summarize key themes, recurring issues, and positive highlights in bullet points:\n\n${textBatch}`
        }]
      });
      if (response.content && response.content[0]?.text) {
        return response.content[0].text;
      }
    } catch (e) {
      console.warn('AI Feedback Summary call failed, using fallback synthesizer:', e.message);
    }
  }

  // Fallback summary synthesizer
  const catCounts = {};
  let stressedCount = 0;
  let totalRating = 0;

  feedbackList.forEach(f => {
    catCounts[f.category] = (catCounts[f.category] || 0) + 1;
    if (f.sentiment === 'Stressed/Negative') stressedCount++;
    totalRating += (f.rating || 5);
  });

  const avgRating = (totalRating / feedbackList.length).toFixed(1);
  const categoriesStr = Object.entries(catCounts).map(([cat, count]) => `${cat} (${count})`).join(', ');

  return `📌 **Feedback Analytics Summary (${feedbackList.length} total entries):**\n\n` +
    `• **Average Satisfaction Rating:** ${avgRating} / 5.0 ⭐\n` +
    `• **Key Feedback Categories:** ${categoriesStr}\n` +
    `• **Stressed / Negative Messages Flagged:** ${stressedCount}\n` +
    `• **Action Recommendations:** Review faculty lab facilities and exam scheduling workload based on recent entries.`;
};

module.exports = { getAIResponse, summarizeFeedbackThemes };
