const Ticket = require('../models/Ticket');
const User = require('../models/User');
const Notification = require('../models/Notification');

const checkAndEscalateTickets = async () => {
  try {
    const hoursThreshold = 48;
    const cutoffTime = new Date(Date.now() - hoursThreshold * 60 * 60 * 1000);
    
    // Find pending or escalated tickets not updated in > 48h
    const tickets = await Ticket.find({
      status: { $in: ['Pending', 'Escalated'] },
      escalationLevel: { $lt: 2 },
      updatedAt: { $lte: cutoffTime }
    }).populate('department student assignedTo');

    console.log(`[Auto-Escalation Check] Found ${tickets.length} tickets pending escalation check.`);

    for (let ticket of tickets) {
      if (ticket.escalationLevel === 0) {
        // Escalate from Faculty -> HOD (admin)
        const hod = await User.findOne({ 
          department: ticket.department._id, 
          role: 'admin' 
        });

        ticket.escalationLevel = 1;
        ticket.status = 'Escalated';
        ticket.lastEscalatedAt = new Date();
        ticket.updatedAt = new Date();
        if (hod) {
          ticket.assignedTo = hod._id;
        }

        ticket.timeline.push({
          status: 'Escalated',
          comment: 'Auto-escalated to HOD (Department Head) due to 48-hour SLA timeout.',
          timestamp: new Date()
        });

        await ticket.save();

        if (hod) {
          await Notification.create({
            user: hod._id,
            title: 'Ticket Escalation Alert',
            message: `Ticket "${ticket.title}" from ${ticket.student.name} auto-escalated to you (HOD).`,
            type: 'ticket',
            link: `/tickets`
          });
        }
      } else if (ticket.escalationLevel === 1) {
        // Escalate from HOD -> Super Admin
        const superAdmin = await User.findOne({ role: 'super_admin' });

        ticket.escalationLevel = 2;
        ticket.status = 'Escalated';
        ticket.lastEscalatedAt = new Date();
        ticket.updatedAt = new Date();
        if (superAdmin) {
          ticket.assignedTo = superAdmin._id;
        }

        ticket.timeline.push({
          status: 'Escalated',
          comment: 'Auto-escalated to Super Admin due to 48-hour HOD SLA timeout.',
          timestamp: new Date()
        });

        await ticket.save();

        if (superAdmin) {
          await Notification.create({
            user: superAdmin._id,
            title: 'Critical Ticket Escalation',
            message: `Ticket "${ticket.title}" auto-escalated to Super Admin final level.`,
            type: 'ticket',
            link: `/tickets`
          });
        }
      }
    }
  } catch (error) {
    console.error('Error running ticket escalation service:', error);
  }
};

module.exports = { checkAndEscalateTickets };
