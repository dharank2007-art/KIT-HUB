const Slot = require('../models/Slot');
const Notification = require('../models/Notification');
const { timeToMinutes } = require('../utils/slotTime');

const checkAndSendSlotReminders = async () => {
  const slots = await Slot.find({
    isCancelled: false,
    'bookings.status': 'Booked'
  }).populate('faculty', 'name').populate('bookings.student', 'name');
  const now = new Date();

  for (const slot of slots) {
    const [year, month, day] = slot.date.split('-').map(Number);
    const startMinutes = timeToMinutes(slot.startTime);
    if (!year || !month || !day || startMinutes === null) continue;
    const startsAt = new Date(year, month - 1, day, Math.floor(startMinutes / 60), startMinutes % 60);
    const minutesUntilStart = startsAt.getTime() - now.getTime();
    if (minutesUntilStart <= 0 || minutesUntilStart > 30 * 60 * 1000) continue;

    for (const booking of slot.bookings) {
      if (booking.status !== 'Booked' || booking.reminderSentAt || !booking.student) continue;
      booking.reminderSentAt = now;
      await slot.save();
      await Notification.create({
        user: booking.student._id,
        title: 'Upcoming Faculty Appointment',
        message: `Your appointment with ${slot.faculty?.name || 'faculty'} starts at ${slot.startTime} (${slot.date}).`,
        type: 'slot',
        link: '/slots'
      });
    }
  }
};

module.exports = { checkAndSendSlotReminders };