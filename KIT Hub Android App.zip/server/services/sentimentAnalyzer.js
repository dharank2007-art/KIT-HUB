const Sentiment = require('sentiment');
const sentimentInstance = new Sentiment();

const analyzeSentiment = (text) => {
  if (!text) {
    return { category: 'Neutral', score: 0 };
  }

  const result = sentimentInstance.analyze(text);
  const score = result.score;

  // Stressed/negative keywords boost
  const stressedKeywords = ['stress', 'depressed', 'anxious', 'harass', 'fail', 'terrible', 'worst', 'abuse', 'unfair', 'unhappy', 'crying', 'help', 'hopeless', 'angry', 'hate'];
  const lowerText = text.toLowerCase();
  const containsStressed = stressedKeywords.some(kw => lowerText.includes(kw));

  let category = 'Neutral';
  if (score < -1 || containsStressed) {
    category = 'Stressed/Negative';
  } else if (score > 1) {
    category = 'Positive';
  }

  return {
    category,
    score,
    tokens: result.tokens,
    words: result.words
  };
};

module.exports = { analyzeSentiment };
