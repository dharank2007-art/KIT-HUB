const PDFDocument = require('pdfkit');

const generateHODReportPDF = (data, res) => {
  const doc = new PDFDocument({ margin: 50 });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="HOD_Monthly_Report_${data.departmentName}_${Date.now()}.pdf"`);

  doc.pipe(res);

  // Header Banner
  doc.rect(0, 0, doc.page.width, 80).fill('#1E3A8A');
  doc.fillColor('#FFFFFF').fontSize(22).text('KIT COLLEGE OF ENGINEERING', 50, 20, { align: 'left' });
  doc.fontSize(14).text(`Monthly Department Performance Report - ${data.departmentName}`, 50, 48, { align: 'left' });

  doc.moveDown(3);
  doc.fillColor('#1E293B');

  // Report Info
  doc.fontSize(12).text(`Generated Date: ${new Date().toLocaleDateString()}`, { align: 'right' });
  doc.text(`Department Code: ${data.departmentCode || 'N/A'}`);
  doc.text(`HOD Name: ${data.hodName || 'N/A'}`);
  doc.moveDown(1);

  // Divider
  doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#CBD5E1');
  doc.moveDown(1);

  // Section 1: Ticket Metrics
  doc.fontSize(16).fillColor('#1E3A8A').text('1. Request Ticket & SLA Metrics', { underline: true });
  doc.moveDown(0.5);
  doc.fontSize(11).fillColor('#334155');
  doc.text(`• Total Tickets Submitted: ${data.tickets.total}`);
  doc.text(`• Approved Tickets: ${data.tickets.approved}`);
  doc.text(`• Pending Tickets: ${data.tickets.pending}`);
  doc.text(`• Escalated Tickets: ${data.tickets.escalated}`);
  doc.moveDown(1.5);

  // Section 2: Faculty Availability Overview
  doc.fontSize(16).fillColor('#1E3A8A').text('2. Faculty Cabin & Class Availability Summary', { underline: true });
  doc.moveDown(0.5);
  doc.fontSize(11).fillColor('#334155');
  if (data.facultyStats && data.facultyStats.length > 0) {
    data.facultyStats.forEach(f => {
      doc.text(`• ${f.name}: Status [${f.status}] - ${f.note || 'No custom note'}`);
    });
  } else {
    doc.text('• No faculty status entries recorded.');
  }
  doc.moveDown(1.5);

  // Section 3: Student Feedback & Sentiment Analysis
  doc.fontSize(16).fillColor('#1E3A8A').text('3. Student Feedback & Sentiment Metrics', { underline: true });
  doc.moveDown(0.5);
  doc.fontSize(11).fillColor('#334155');
  doc.text(`• Total Feedback Entries: ${data.feedback.total}`);
  doc.text(`• Average Rating: ${data.feedback.avgRating} / 5.0`);
  doc.text(`• Stressed / Negative Sentiment Alerts: ${data.feedback.stressedCount}`);
  doc.moveDown(0.5);
  doc.text('AI Theme Summary:');
  doc.fontSize(10).fillColor('#475569').text(data.feedback.summary || 'N/A', { indent: 15 });
  doc.moveDown(1.5);

  // Section 4: Early Warning & Low Performers
  doc.fontSize(16).fillColor('#1E3A8A').text('4. Academic Early Warning Flags', { underline: true });
  doc.moveDown(0.5);
  doc.fontSize(11).fillColor('#334155');
  doc.text(`• Total Flagged Low Performers (<75% attendance / <50% marks): ${data.earlyWarnings.totalFlagged}`);
  if (data.earlyWarnings.students && data.earlyWarnings.students.length > 0) {
    data.earlyWarnings.students.forEach(s => {
      doc.text(`  - ${s.name} (${s.registerNumber}): Attendance ${s.attendance}%, Marks ${s.marks}% [Mentor: ${s.mentorName}]`);
    });
  }
  doc.moveDown(2);

  // Footer
  doc.fontSize(10).fillColor('#94A3B8').text('Confidential - Internal Academic Quality Report | KIT College Management System', 50, 720, { align: 'center' });

  doc.end();
};

module.exports = { generateHODReportPDF };
