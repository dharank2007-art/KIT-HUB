const timeToMinutes = (value) => {
  if (typeof value !== 'string') return null;
  const match = value.match(/^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i);
  if (!match) return null;
  let hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (minutes > 59 || hours > 23) return null;
  if (match[3]) {
    if (hours < 1 || hours > 12) return null;
    hours = hours % 12 + (match[3].toUpperCase() === 'PM' ? 12 : 0);
  }
  return hours * 60 + minutes;
};

const isTenMinuteRange = (startTime, endTime) => {
  const start = timeToMinutes(startTime);
  const end = timeToMinutes(endTime);
  return start !== null && end !== null && end - start === 10;
};

module.exports = { timeToMinutes, isTenMinuteRange };