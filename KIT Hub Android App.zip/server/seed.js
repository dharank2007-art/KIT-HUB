const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Department = require('./models/Department');
const FAQ = require('./models/FAQ');
const Announcement = require('./models/Announcement');
const Ticket = require('./models/Ticket');
const Availability = require('./models/Availability');
const Slot = require('./models/Slot');
const AcademicRecord = require('./models/AcademicRecord');
const ValidStudent = require('./models/ValidStudent');

dotenv.config();

const getOrCreateUser = async (attributes) => {
  let user = await User.findOne({ email: attributes.email });
  if (!user) {
    user = new User(attributes);
    await user.save();
  }
  return user;
};

const seedDB = async () => {
  try {
    const connStr = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/kit_college_db';
    console.log(`Connecting to MongoDB at ${connStr}...`);
    
    await mongoose.connect(connStr, {
      serverSelectionTimeoutMS: 4000
    });
    console.log('Connected to MongoDB for seeding.');

    if (process.env.SEED_RESET === 'true') {
      await mongoose.connection.dropDatabase();
      console.log('Database reset requested with SEED_RESET=true.');
    }

    // 1. Create Departments
    const deptCSE = await Department.findOneAndUpdate({ code: 'CSE' }, {
      $setOnInsert: {
        name: 'Computer Science & Engineering',
        code: 'CSE',
        description: 'Department of Computer Science & Engineering'
      }
    }, { new: true, upsert: true });

    const deptECE = await Department.findOneAndUpdate({ code: 'ECE' }, {
      $setOnInsert: {
        name: 'Electronics & Communication Engineering',
        code: 'ECE',
        description: 'Department of Electronics & Communication'
      }
    }, { new: true, upsert: true });

    const superAdmin = await getOrCreateUser({
      name: 'System Super Admin',
      email: 'superadmin@kit.edu',
      password: 'Admin@123',
      role: 'super_admin',
      employeeId: 'EMP0001',
      phone: '+91 9876543210',
      isPasswordChanged: false
    });

    console.log('Departments created.');

    // 2. Create Super Admin
    // 3. Create 3 Faculty (including 1 HOD)
    // HOD CSE (Role: admin)
    const hodCSE = await getOrCreateUser({
      name: 'Dr. R. Sharma',
      email: 'hod.cse@kit.edu',
      password: 'Faculty@123',
      role: 'admin', // admin = HOD
      department: deptCSE._id,
      employeeId: 'EMP0101',
      phone: '+91 9876543211',
      isPasswordChanged: false
    });

    deptCSE.hod = hodCSE._id;
    await deptCSE.save();

    // Faculty 1 CSE (Role: staff)
    const faculty1 = await getOrCreateUser({
      name: 'Prof. Anita V',
      email: 'faculty.anita@kit.edu',
      password: 'Faculty@123',
      role: 'staff', // staff = Faculty
      department: deptCSE._id,
      employeeId: 'EMP0102',
      phone: '+91 9876543212',
      isPasswordChanged: false
    });

    // Faculty 2 ECE (Role: staff)
    const faculty2 = await getOrCreateUser({
      name: 'Prof. Suresh Kumar',
      email: 'faculty.kumar@kit.edu',
      password: 'Faculty@123',
      role: 'staff',
      department: deptECE._id,
      employeeId: 'EMP0201',
      phone: '+91 9876543213',
      isPasswordChanged: false
    });

    console.log('Faculty & HOD created.');

    // 4. Create 10 Students (Role: student)
    const depts = [deptCSE._id, deptCSE._id, deptCSE._id, deptCSE._id, deptCSE._id, deptECE._id, deptECE._id, deptECE._id, deptECE._id, deptECE._id];

    const studentNames = [
      'Aravind Swamy', 'Bhavana Krishna', 'Chetan Kumar', 'Divya Ramesh', 'Ezhil Arasan',
      'Farhan Akhtar', 'Gopika Menon', 'Hariharan V', 'Ishwarya Roy', 'Jayendra N'
    ];

    const students = [];
    for (let i = 0; i < 10; i++) {
      const student = await getOrCreateUser({
        name: studentNames[i],
        email: `student${i + 1}@kit.edu`,
        password: 'Student@123',
        role: 'student',
        department: depts[i],
        registerNumber: `73162110400${i + 1}`,
        className: i < 5 ? 'III-A' : 'II-A',
        bloodGroup: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'B+', 'O+'][i],
        linkedin: `https://www.linkedin.com/in/kit-student-${i + 1}`,
        phone: `+91 900000000${i}`,
        assignedMentor: i < 5 ? (i % 2 ? faculty1._id : hodCSE._id) : faculty2._id,
        isPasswordChanged: false
      });
      students.push(student);
      await ValidStudent.findOneAndUpdate(
        { registerNumber: student.registerNumber.toUpperCase() },
        { $setOnInsert: {
          registerNumber: student.registerNumber.toUpperCase(),
          department: student.department,
          className: student.className
        } },
        { upsert: true, new: true }
      );
    }

    console.log('10 Students created.');

    // 5. Seed Faculty Availabilities
    await Availability.findOneAndUpdate({ faculty: hodCSE._id }, { $setOnInsert: {
      faculty: hodCSE._id,
      status: 'In cabin',
      note: 'Available for HOD consultations until 4:30 PM',
      location: 'CSE HOD Cabin (Block A-201)'
    } }, { upsert: true });
    await Availability.findOneAndUpdate({ faculty: faculty1._id }, { $setOnInsert: {
      faculty: faculty1._id,
      status: 'Free',
      note: 'Free for student doubts in Staff Room',
      location: 'Staff Room 104'
    } }, { upsert: true });
    await Availability.findOneAndUpdate({ faculty: faculty2._id }, { $setOnInsert: {
      faculty: faculty2._id,
      status: 'In class',
      note: 'Lecturing ECE Digital Electronics Lab',
      location: 'Electronics Lab 2'
    } }, { upsert: true });

    // 6. Seed Slots
    const todayStr = new Date().toISOString().split('T')[0];
    await Slot.findOneAndUpdate({ faculty: faculty1._id, date: todayStr, startTime: '02:00 PM' }, { $setOnInsert: {
      faculty: faculty1._id,
      date: todayStr,
      startTime: '02:00 PM',
      endTime: '02:10 PM',
      location: 'Cabin 104',
      maxStudents: 1,
      notes: '1-on-1 Mini Project Review'
    } }, { upsert: true });

    // 7. Seed Sample FAQs
    if (!await FAQ.exists({})) await FAQ.create([
      {
        question: 'How do I apply for On Duty (OD) leave?',
        answer: 'Navigate to "Request Tickets" -> Click "New Ticket" -> Select Type "OD" -> Fill details and attach proof -> Submit for Faculty approval.',
        category: 'Attendance & OD'
      },
      {
        question: 'What is the minimum attendance criteria?',
        answer: 'Students must maintain a minimum of 75% attendance in each course to be eligible for end-semester examinations.',
        category: 'Academic Regulations'
      },
      {
        question: 'How do I book a meeting slot with a Faculty member?',
        answer: 'Go to "Faculty Availability & Slots" -> Select your target Faculty member -> Click on an open 10-minute slot -> Confirm booking reason.',
        category: 'Faculty Meetings'
      }
    ]);

    // 8. Seed Announcements
    if (!await Announcement.exists({})) await Announcement.create([
      {
        title: 'Campus Hackathon 2026 Registration Open',
        content: 'Registration is now open for all CSE and ECE students for the annual KIT TechFest Hackathon.',
        author: superAdmin._id,
        isGlobal: true,
        isCommunityBoard: true
      },
      {
        title: 'CSE Mid-Semester Assessment Schedule',
        content: 'Please find the schedule for CSE 3rd Year mid-semester lab evaluations starting next Monday.',
        author: hodCSE._id,
        department: deptCSE._id,
        isGlobal: false
      }
    ]);

    // 9. Seed Academic Records for Early Warning Dashboard
    for (let i = 0; i < 10; i++) {
      const isLowAtt = (i === 2 || i === 6);
      const isLowMarks = (i === 4 || i === 6);
      const existingRecord = await AcademicRecord.findOne({
        student: students[i]._id,
        semester: 'Semester 5',
        subject: 'Data Structures & Algorithms'
      });
      if (!existingRecord) {
        await AcademicRecord.create({
          student: students[i]._id,
          department: students[i].department,
          semester: 'Semester 5',
          subject: 'Data Structures & Algorithms',
          attendancePercentage: isLowAtt ? 62 : 88,
          marksPercentage: isLowMarks ? 42 : 78,
          remarks: isLowAtt || isLowMarks ? 'Needs immediate academic counseling and attendance recovery.' : 'Satisfactory progress.'
        });
      }
    }

    console.log('\n✅ Database seeding complete successfully!');
    console.log('\n--- CREDENTIALS FOR TESTING ---');
    console.log('Super Admin:  superadmin@kit.edu / Admin@123');
    console.log('HOD (Admin):  hod.cse@kit.edu    / Faculty@123');
    console.log('Faculty:      faculty.anita@kit.edu / Faculty@123');
    console.log('Student:      student1@kit.edu   / Student@123');
    console.log('-------------------------------\n');

    process.exit(0);
  } catch (error) {
    console.warn('Seeding warning (MongoDB offline or timeout):', error.message);
    process.exitCode = 1;
  }
};

seedDB();
