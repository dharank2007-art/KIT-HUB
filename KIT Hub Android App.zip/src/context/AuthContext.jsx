import React, { createContext, useState, useEffect, useContext } from 'react';
import { apiFetch } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('kit_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('kit_token') || '');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      // Refresh user profile
      apiFetch('/auth/me')
        .then(data => {
          setUser(data);
          localStorage.setItem('kit_user', JSON.stringify(data));
        })
        .catch(error => {
          if (error.status === 401 || error.status === 403) logout();
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [token]);

  const login = (userData, authToken) => {
    setUser(userData);
    setToken(authToken);
    localStorage.setItem('kit_user', JSON.stringify(userData));
    localStorage.setItem('kit_token', authToken);
  };

  const logout = () => {
    setUser(null);
    setToken('');
    localStorage.removeItem('kit_user');
    localStorage.removeItem('kit_token');
  };

  const updateUser = (updatedFields) => {
    setUser(prev => {
      const newU = { ...prev, ...updatedFields };
      localStorage.setItem('kit_user', JSON.stringify(newU));
      return newU;
    });
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, updateUser, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
