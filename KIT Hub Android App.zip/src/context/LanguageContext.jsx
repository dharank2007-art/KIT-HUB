import React, { createContext, useState, useContext } from 'react';

const translations = {
  en: {
    appName: "KIT College App",
    dashboard: "Dashboard",
    tickets: "Request Tickets",
    availability: "Faculty Availability",
    slotBooking: "Book 10-Min Slot",
    doubtWall: "Doubt Wall",
    feedback: "Anonymous Feedback",
    mentorDiary: "Mentor Diary",
    aiAssistant: "AI Assistant",
    earlyWarning: "Early Warning",
    achievements: "Achievement Wall",
    announcements: "Announcements & Circulars",
    chat: "1:1 Messages",
    directory: "User Directory",
    bloodFinder: "Blood Group Finder",
    myProfile: "My Profile & Export",
    registrations: "Student Approvals",
    communityBoard: "Community Board",
    bulkUpload: "Bulk CSV Upload",
    hodReport: "HOD Monthly PDF",
    changePassword: "Change Password",
    logout: "Logout",
    welcome: "Welcome back",
    roleSuperAdmin: "Super Admin",
    roleHOD: "HOD (Head of Department)",
    roleFaculty: "Faculty (Staff)",
    roleStudent: "Student",
    pending: "Pending",
    approved: "Approved",
    rejected: "Rejected",
    escalated: "Escalated",
    inClass: "In Class",
    inCabin: "In Cabin",
    free: "Free",
    onLeave: "On Leave",
    search: "Search...",
    submit: "Submit",
    cancel: "Cancel"
  },
  ta: {
    appName: "கே.ஐ.டி கல்லூரி செயலி",
    dashboard: "முகப்பு பலகை",
    tickets: "கோரிக்கை சீட்டுகள்",
    availability: "பேராசிரியர் நிலை",
    slotBooking: "நேரம் ஒதுக்கல் (10 நிமி)",
    doubtWall: "சந்தேக சுவர்",
    feedback: "ரகசிய கருத்துகள்",
    mentorDiary: "வழிகாட்டி குறிப்பேடு",
    aiAssistant: "AI உதவி உதவியாளர்",
    earlyWarning: "முன்னெச்சரிக்கை பலகை",
    achievements: "சாதனை சுவர்",
    announcements: "அறிவிப்புகள் & சுற்றறிக்கைகள்",
    chat: "1:1 உரையாடல்",
    directory: "பயனர் விபரம்",
    bloodFinder: "இரத்த வகை தேடல்",
    myProfile: "என் சுயவிவரம் மற்றும் ஏற்றுமதி",
    registrations: "மாணவர் ஒப்புதல்கள்",
    communityBoard: "சமூக பலகை",
    bulkUpload: "மொத்த CSV பதிவேற்றம்",
    hodReport: "துறை தலைவர் PDF அறிக்கை",
    changePassword: "கடவுச்சொல்லை மாற்று",
    logout: "வெளியேறு",
    welcome: "நல்வரவு",
    roleSuperAdmin: "முதன்மை நிர்வாகி",
    roleHOD: "துறைத் தலைவர் (HOD)",
    roleFaculty: "பேராசிரியர்",
    roleStudent: "மாணவர்",
    pending: "நிலுவையில்",
    approved: "அங்கீகரிக்கப்பட்டது",
    rejected: "நிராகரிக்கப்பட்டது",
    escalated: "மேல்முறையீடு செய்யப்பட்டது",
    inClass: "வகுப்பில்",
    inCabin: "அறையில்",
    free: "கிடைக்கிறார்",
    onLeave: "விடுப்பில்",
    search: "தேடுக...",
    submit: "சமர்ப்பி",
    cancel: "ரத்து செய்"
  }
};

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState('en');

  const toggleLanguage = () => {
    setLang(prev => prev === 'en' ? 'ta' : 'en');
  };

  const t = (key) => {
    return translations[lang][key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
