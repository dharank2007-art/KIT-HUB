import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { QrCode, CheckCircle, Camera } from 'lucide-react';

export const QRCheckinModal = ({ onClose }) => {
  const { user } = useAuth();
  const [scanned, setScanned] = useState(false);
  const [locationName, setLocationName] = useState('CSE Lab 3 / Faculty Cabin A-201');

  const handleSimulateScan = () => {
    setScanned(true);
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 text-slate-800 text-center space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <QrCode className="w-5 h-5 text-amber-500" />
            QR Check-in & Attendance
          </h2>
          <button onClick={onClose} className="text-slate-400 font-bold">✕</button>
        </div>

        {scanned ? (
          <div className="py-6 space-y-2 text-emerald-600">
            <CheckCircle className="w-16 h-16 mx-auto animate-bounce text-emerald-500" />
            <h3 className="font-extrabold text-lg text-slate-900">Check-in Verified!</h3>
            <p className="text-xs text-slate-500 font-medium">
              Checked in at {locationName} for {user?.name}.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-xs text-slate-600">
              Scan cabin or classroom QR code to record instant check-in.
            </p>

            {/* Generated QR Mockup */}
            <div className="w-48 h-48 mx-auto bg-slate-900 p-3 rounded-2xl flex items-center justify-center border-4 border-amber-400 shadow-xl">
              <svg viewBox="0 0 100 100" className="w-full h-full fill-white">
                <rect x="10" y="10" width="25" height="25" fill="white" />
                <rect x="15" y="15" width="15" height="15" fill="black" />
                <rect x="65" y="10" width="25" height="25" fill="white" />
                <rect x="70" y="15" width="15" height="15" fill="black" />
                <rect x="10" y="65" width="25" height="25" fill="white" />
                <rect x="15" y="70" width="15" height="15" fill="black" />
                <rect x="45" y="45" width="10" height="10" fill="amber" />
                <rect x="40" y="20" width="15" height="10" fill="white" />
                <rect x="40" y="70" width="20" height="15" fill="white" />
                <rect x="70" y="45" width="15" height="20" fill="white" />
              </svg>
            </div>

            <p className="text-[11px] text-slate-400 font-mono">Location ID: KIT-CSE-CABIN-201</p>

            <button
              onClick={handleSimulateScan}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
            >
              <Camera className="w-4 h-4" />
              Simulate Camera QR Scan
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
