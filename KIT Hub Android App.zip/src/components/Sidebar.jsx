import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  LayoutDashboard, 
  Ticket, 
  Clock, 
  Calendar, 
  HelpCircle, 
  MessageSquareOff, 
  BookOpen, 
  Bot, 
  AlertTriangle, 
  Trophy, 
  Megaphone, 
  MessageCircle, 
  Users, 
  FileSpreadsheet, 
  FileText,
  KeyRound,
  HeartPulse,
  UserRoundCheck,
  UserRound
} from 'lucide-react';

export const Sidebar = () => {
  const { user } = useAuth();
  const { t } = useLanguage();

  const navItems = [
    { path: '/', label: t('dashboard'), icon: LayoutDashboard, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/tickets', label: t('tickets'), icon: Ticket, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/availability', label: t('availability'), icon: Clock, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/slots', label: t('slotBooking'), icon: Calendar, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/doubts', label: t('doubtWall'), icon: HelpCircle, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/feedback', label: t('feedback'), icon: MessageSquareOff, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/mentor-diary', label: t('mentorDiary'), icon: BookOpen, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/ai-assistant', label: t('aiAssistant'), icon: Bot, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/early-warning', label: t('earlyWarning'), icon: AlertTriangle, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/achievements', label: t('achievements'), icon: Trophy, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/announcements', label: t('announcements'), icon: Megaphone, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/chat', label: t('chat'), icon: MessageCircle, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/directory', label: t('directory'), icon: Users, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/blood-finder', label: t('bloodFinder'), icon: HeartPulse, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/profile', label: t('myProfile'), icon: UserRound, roles: ['super_admin', 'admin', 'staff', 'student'] },
    { path: '/admin/registrations', label: t('registrations'), icon: UserRoundCheck, roles: ['admin', 'super_admin'] },
    { path: '/bulk-upload', label: t('bulkUpload'), icon: FileSpreadsheet, roles: ['super_admin'] },
    { path: '/change-password', label: t('changePassword'), icon: KeyRound, roles: ['super_admin', 'admin', 'staff', 'student'] }
  ];

  const visibleItems = navItems.filter(item => item.roles.includes(user?.role));

  return (
    <>
    <nav aria-label="Main navigation" className="flex shrink-0 gap-1 overflow-x-auto border-b border-[#dce3de] bg-white p-2 lg:hidden">
      {visibleItems.map(item => {
        const Icon = item.icon;
        return <NavLink key={item.path} to={item.path} end={item.path === '/'} aria-label={item.label} className={({ isActive }) => `flex shrink-0 items-center gap-2 rounded-md px-3 py-2 text-xs font-semibold ${isActive ? 'bg-[#e9f1eb] text-[#285c47]' : 'text-[#52645a] hover:bg-[#f2f6f3]'}`}>
          <Icon className="h-4 w-4" /><span>{item.label}</span>
        </NavLink>;
      })}
    </nav>
    <aside className="hidden min-h-[calc(100vh-4rem)] w-64 shrink-0 flex-col justify-between border-r border-[#dce3de] bg-white p-4 text-[#52645a] lg:flex">
      <div className="space-y-1">
        <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-[#87938d]">
          Navigation Menu
        </div>
        {visibleItems.map(item => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) => `
                flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors
                ${isActive
                  ? 'bg-[#e9f1eb] font-semibold text-[#285c47]'
                  : 'text-[#52645a] hover:bg-[#f2f6f3] hover:text-[#243b31]'
                }
              `}
            >
              <Icon className="w-5 h-5 shrink-0" />
              <span className="truncate">{item.label}</span>
            </NavLink>
          );
        })}
      </div>

      {/* Role Footer Info */}
      <div className="border-t border-[#dce3de] px-3 pt-4">
        <div className="space-y-1 rounded-md bg-[#f5f7f5] p-3 text-xs">
          <p className="font-medium text-[#718079]">Signed in as</p>
          <p className="truncate font-bold text-[#243b31]">{user?.name}</p>
          <p className="text-[11px] capitalize text-[#8a6740]">{user?.role?.replace('_', ' ')}</p>
        </div>
      </div>
    </aside>
    </>
  );
};
