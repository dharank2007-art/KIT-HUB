import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../services/api';
import { Bell, Globe, LayoutDashboard, LogOut, QrCode, Shield } from 'lucide-react';
import { NavLink } from 'react-router-dom';

export const Navbar = ({ onOpenQR }) => {
  const { user, logout } = useAuth();
  const { lang, toggleLanguage, t } = useLanguage();
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (user) {
      loadNotifications();
    }
  }, [user]);

  const loadNotifications = async () => {
    try {
      const res = await apiFetch('/notifications');
      setNotifications(res);
    } catch (e) {
      console.error(e);
    }
  };

  const markAsRead = async (id) => {
    try {
      await apiFetch(`/notifications/${id}/read`, { method: 'PUT' });
      setNotifications(prev => prev.map(n => n._id === id ? { ...n, read: true } : n));
    } catch (e) {
      console.error(e);
    }
  };

  const markAllRead = async () => {
    try {
      await apiFetch('/notifications/read-all', { method: 'PUT' });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (e) {
      console.error(e);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const roleLabels = {
    super_admin: 'Super Admin',
    admin: 'HOD',
    staff: 'Faculty',
    student: 'Student'
  };

  const roleColors = {
    super_admin: 'bg-violet-50 text-violet-800 border-violet-200',
    admin: 'bg-blue-100 text-blue-800 border-blue-300',
    staff: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    student: 'bg-amber-100 text-amber-800 border-amber-300'
  };

  return (
    <header className="sticky top-0 z-30 border-b border-[#dce3de] bg-white text-[#243b31]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Left: Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#285c47]">
            <Shield className="h-5 w-5 text-[#f2ca78]" />
          </div>
          <div>
            <h1 className="flex items-center gap-2 text-base font-bold text-[#243b31]">
              {t('appName')}
            </h1>
            <p className="hidden text-xs font-medium text-[#728078] sm:block">
              {user?.department?.name || 'KIT Campus'}
            </p>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <NavLink to="/" end className={({ isActive }) => `inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold transition ${isActive ? 'bg-[#e9f1eb] text-[#285c47]' : 'text-[#56675e] hover:bg-[#f2f6f3] hover:text-[#285c47]'}`}>
            <LayoutDashboard className="h-4 w-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </NavLink>
          
          {/* QR Checkin Button */}
          <button
            onClick={onOpenQR}
            className="flex items-center gap-1.5 rounded-md border border-[#dce3de] px-2.5 py-2 text-xs font-semibold text-[#46594f] transition hover:bg-[#f2f6f3]"
            title="QR Code Check-in"
          >
            <QrCode className="w-4 h-4 text-[#285c47]" />
            <span className="hidden md:inline">QR Check-in</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 rounded-md border border-[#dce3de] px-2.5 py-2 text-xs font-semibold text-[#46594f] transition hover:bg-[#f2f6f3]"
            title="Toggle Language (Tamil / English)"
          >
            <Globe className="w-4 h-4 text-[#285c47]" />
            <span className="uppercase font-bold">{lang}</span>
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative rounded-md border border-[#dce3de] p-2 text-[#52645a] transition hover:bg-[#f2f6f3]"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-[#b94b3b] text-[10px] font-bold text-white">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 z-50 mt-2 w-80 overflow-hidden rounded-md border border-[#dce3de] bg-white text-slate-800 shadow-xl sm:w-96">
                <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="font-bold text-sm text-slate-800">Notifications</h3>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-xs text-blue-600 hover:underline font-medium"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-xs text-slate-500">No notifications yet.</div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n._id}
                        onClick={() => markAsRead(n._id)}
                        className={`p-3 text-xs cursor-pointer hover:bg-slate-50 transition ${!n.read ? 'bg-blue-50/60 font-medium' : ''}`}
                      >
                        <div className="flex items-center justify-between font-semibold text-slate-900 mb-1">
                          <span>{n.title}</span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-600">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Pill */}
          <div className="flex items-center gap-2 border-l border-[#dce3de] pl-2">
            <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-[#dcebe0] text-xs font-bold text-[#285c47]">
              {user?.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                user?.name ? user.name.charAt(0).toUpperCase() : 'U'
              )}
            </div>
            <div className="hidden text-left text-xs lg:block">
              <div className="max-w-[120px] truncate font-bold text-[#243b31]">{user?.name}</div>
              <span className={`inline-block px-1.5 py-0.2 text-[10px] font-bold rounded border ${roleColors[user?.role] || ''}`}>
                {roleLabels[user?.role] || user?.role}
              </span>
            </div>
          </div>

          {/* Logout button */}
          <button
            onClick={logout}
            className="rounded-md p-2 text-[#718079] transition hover:bg-[#fbefed] hover:text-[#a14034]"
            title={t('logout')}
          >
            <LogOut className="w-5 h-5" />
          </button>

        </div>
      </div>
    </header>
  );
};
