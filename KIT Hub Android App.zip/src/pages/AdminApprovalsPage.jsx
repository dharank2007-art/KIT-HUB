import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { apiFetch } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Check, FileSpreadsheet, Trash2, UserRoundCheck, X } from 'lucide-react';

const parseRosterCsv = (text) => {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) throw new Error('Add a header and at least one roster row');
  const headers = lines[0].split(',').map(value => value.trim());
  return lines.slice(1).map(line => {
    const cells = line.split(',');
    return Object.fromEntries(headers.map((header, index) => [header, (cells[index] || '').trim()]));
  });
};

export const AdminApprovalsPage = () => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const requestedStatus = searchParams.get('status');
  const [status, setStatus] = useState(['pending', 'approved', 'rejected'].includes(requestedStatus) ? requestedStatus : 'pending');
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [rosterCsv, setRosterCsv] = useState('registerNumber,department,className\n21CS042,CSE,III-A');
  const [rosterMessage, setRosterMessage] = useState('');
  const isAdmin = ['admin', 'super_admin'].includes(user?.role);

  useEffect(() => {
    if (!isAdmin) return;
    setLoading(true);
    apiFetch(`/users/approvals?status=${status}`)
      .then(setStudents)
      .catch(error => setRosterMessage(error.message))
      .finally(() => setLoading(false));
  }, [status, isAdmin]);

  useEffect(() => {
    if (['pending', 'approved', 'rejected'].includes(requestedStatus)) setStatus(requestedStatus);
  }, [requestedStatus]);

  const review = async (student, nextStatus) => {
    try {
      await apiFetch(`/users/${student._id}/approval`, {
        method: 'PATCH',
        body: JSON.stringify({ status: nextStatus })
      });
      setStudents(current => current.filter(entry => entry._id !== student._id));
    } catch (error) {
      alert(error.message);
    }
  };

  const removeStudent = async (student) => {
    if (!window.confirm(`Delete the account for ${student.name}?`)) return;
    try {
      await apiFetch(`/users/${student._id}`, { method: 'DELETE' });
      setStudents(current => current.filter(entry => entry._id !== student._id));
    } catch (error) {
      alert(error.message);
    }
  };

  const importRoster = async (event) => {
    event.preventDefault();
    try {
      const result = await apiFetch('/valid-students/bulk-csv', {
        method: 'POST',
        body: JSON.stringify({ rows: parseRosterCsv(rosterCsv) })
      });
      setRosterMessage(`Imported or updated ${result.importedCount} roster records; ${result.errors.length} row errors.`);
    } catch (error) {
      setRosterMessage(error.message);
    }
  };

  if (!isAdmin) return <p className="p-8 text-center text-slate-600">Administrator access required.</p>;

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3 border-b border-slate-200 pb-4">
        <UserRoundCheck className="h-6 w-6 text-blue-700" />
        <div>
          <h1 className="text-xl font-bold text-slate-900">Student Registration Review</h1>
          <p className="text-sm text-slate-500">Review eligibility details and manage admission status.</p>
        </div>
      </header>

      <section className="grid gap-6 xl:grid-cols-[1fr_22rem]">
        <div>
          <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3">
            {['pending', 'approved', 'rejected'].map(tab => (
              <button key={tab} onClick={() => { setStatus(tab); setSearchParams({ status: tab }); }} className={`rounded-md px-3 py-2 text-xs font-bold capitalize ${status === tab ? 'bg-slate-900 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
                {tab}
              </button>
            ))}
          </div>
          {loading ? <p className="p-8 text-center text-sm text-slate-500">Loading registrations...</p> : students.length === 0 ? (
            <p className="p-8 text-center text-sm text-slate-500">No {status} registrations.</p>
          ) : (
            <div className="divide-y divide-slate-200">
              {students.map(student => (
                <article key={student._id} className="space-y-3 py-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h2 className="font-bold text-slate-900">{student.name}</h2>
                      <p className="text-xs text-slate-500">{student.registerNumber} · {student.department?.code} · {student.className}</p>
                    </div>
                    <span className="rounded border border-slate-200 px-2 py-1 text-[11px] font-bold capitalize text-slate-600">{student.status}</span>
                  </div>
                  <div className="grid gap-2 text-xs text-slate-700 sm:grid-cols-2">
                    <p>{student.email}</p><p>{student.phone || 'No phone provided'} · {student.bloodGroup}</p>
                    <a className="truncate text-blue-700 underline" href={student.linkedin} target="_blank" rel="noreferrer">LinkedIn profile</a>
                    {student.portfolio && <a className="truncate text-blue-700 underline" href={student.portfolio} target="_blank" rel="noreferrer">Portfolio</a>}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {student.status !== 'approved' && <button onClick={() => review(student, 'approved')} className="inline-flex items-center gap-1 rounded-md bg-emerald-700 px-3 py-2 text-xs font-bold text-white"><Check className="h-4 w-4" />Approve</button>}
                    {student.status !== 'rejected' && <button onClick={() => review(student, 'rejected')} className="inline-flex items-center gap-1 rounded-md border border-rose-300 bg-white px-3 py-2 text-xs font-bold text-rose-700"><X className="h-4 w-4" />Reject</button>}
                    <button onClick={() => removeStudent(student)} title="Delete student" className="inline-flex items-center rounded-md border border-slate-200 px-3 py-2 text-slate-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>

        <aside className="h-fit border-t border-slate-200 pt-5 xl:border-l xl:border-t-0 xl:pl-6 xl:pt-0">
          <h2 className="flex items-center gap-2 font-bold text-slate-900"><FileSpreadsheet className="h-4 w-4 text-emerald-700" />Eligible Student Roster</h2>
          <p className="mt-1 text-xs text-slate-500">CSV headers: registerNumber, department, className</p>
          <form onSubmit={importRoster} className="mt-3 space-y-3">
            <textarea required rows={7} value={rosterCsv} onChange={event => setRosterCsv(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-3 font-mono text-xs text-slate-800" />
            <button className="w-full rounded-md bg-emerald-700 px-3 py-2.5 text-xs font-bold text-white">Import eligible roster</button>
            {rosterMessage && <p className="text-xs text-slate-600" role="status">{rosterMessage}</p>}
          </form>
        </aside>
      </section>
    </div>
  );
};