import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { BookOpen, Plus, Calendar, User, Target, FileText, CheckCircle2 } from 'lucide-react';

export const MentorDiaryPage = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState([]);
  const [mentees, setMentees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  // Form states
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [topicsDiscussed, setTopicsDiscussed] = useState('');
  const [goals, setGoals] = useState('');
  const [mentorNotes, setMentorNotes] = useState('');
  const [academicStatus, setAcademicStatus] = useState('Satisfactory');
  const [followUpDate, setFollowUpDate] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const diaryRes = await apiFetch('/mentor-diary');
      setEntries(diaryRes);

      if (['staff', 'admin', 'super_admin'].includes(user?.role)) {
        const studentRes = await apiFetch('/users?role=student');
        setMentees(studentRes);
        if (studentRes.length > 0) setSelectedStudentId(studentRes[0]._id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEntry = async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/mentor-diary', {
        method: 'POST',
        body: JSON.stringify({
          studentId: selectedStudentId,
          topicsDiscussed,
          goals,
          mentorNotes,
          academicStatus,
          followUpDate: followUpDate || null
        })
      });
      setTopicsDiscussed('');
      setGoals('');
      setMentorNotes('');
      setShowModal(false);
      loadData();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-blue-600" />
            Mentor-Mentee Confidential Academic Diary
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Mentors log 1-on-1 counseling meetings, set goals, and record notes; students view their personal progress log.
          </p>
        </div>

        {['staff', 'admin', 'super_admin'].includes(user?.role) && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            <Plus className="w-4 h-4" />
            Log Mentoring Session
          </button>
        )}
      </div>

      {/* Diary Entries Feed */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading diary entries...</div>
      ) : entries.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No mentoring session entries logged yet.
        </div>
      ) : (
        <div className="space-y-4">
          {entries.map(e => (
            <div key={e._id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                    {e.student?.name?.charAt(0) || 'S'}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{e.student?.name} ({e.student?.registerNumber})</h3>
                    <p className="text-xs text-slate-500">Mentor: {e.mentor?.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[11px] rounded-full">
                    {e.academicStatus}
                  </span>
                  <span className="text-xs text-slate-400">
                    {new Date(e.date).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-1">
                  <p className="font-bold text-slate-800 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-blue-600" /> Topics Discussed:
                  </p>
                  <p className="text-slate-700 leading-relaxed">{e.topicsDiscussed}</p>
                </div>

                <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/80 space-y-1">
                  <p className="font-bold text-amber-900 flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-amber-600" /> Goals & Targets:
                  </p>
                  <p className="text-amber-950 leading-relaxed">{e.goals || 'No specific goals recorded.'}</p>
                </div>
              </div>

              {e.mentorNotes && (
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-xs text-blue-950">
                  <span className="font-bold">Mentor Confidential Remarks:</span> {e.mentorNotes}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Log Session Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Log Mentoring Meeting Record</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateEntry} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Select Mentee Student</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                >
                  {mentees.map(m => (
                    <option key={m._id} value={m._id}>{m.name} ({m.registerNumber || m.email})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Topics Discussed</label>
                <textarea
                  required
                  rows={3}
                  value={topicsDiscussed}
                  onChange={(e) => setTopicsDiscussed(e.target.value)}
                  placeholder="e.g. Discussed attendance drop in DSA and career interest in AI..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Goals & Action Items</label>
                <input
                  type="text"
                  value={goals}
                  onChange={(e) => setGoals(e.target.value)}
                  placeholder="e.g. Complete 2 LeetCode problems weekly, attend remedial class"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mentor Private Notes</label>
                <input
                  type="text"
                  value={mentorNotes}
                  onChange={(e) => setMentorNotes(e.target.value)}
                  placeholder="Observation notes..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Status</label>
                  <select
                    value={academicStatus}
                    onChange={(e) => setAcademicStatus(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                  >
                    <option value="Satisfactory">Satisfactory</option>
                    <option value="Needs Improvement">Needs Improvement</option>
                    <option value="Critical Flag">Critical Flag</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Follow-up Date</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
