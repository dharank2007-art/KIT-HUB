import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { AlertTriangle, Plus, FileSpreadsheet, Bell, CheckCircle, Search } from 'lucide-react';

export const EarlyWarningPage = () => {
  const { user } = useAuth();
  const [records, setRecords] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [showManualModal, setShowManualModal] = useState(false);
  const [showCsvModal, setShowCsvModal] = useState(false);

  // Manual Form
  const [selectedStudent, setSelectedStudent] = useState('');
  const [semester, setSemester] = useState('Semester 5');
  const [subject, setSubject] = useState('Data Structures & Algorithms');
  const [attendancePercentage, setAttendancePercentage] = useState(80);
  const [marksPercentage, setMarksPercentage] = useState(70);
  const [remarks, setRemarks] = useState('');

  // CSV text
  const [csvText, setCsvText] = useState('registerNumber,semester,subject,attendancePercentage,marksPercentage,remarks\n731621104001,Semester 5,Data Structures,64,45,Needs counseling');

  useEffect(() => {
    loadRecords();
  }, [flaggedOnly]);

  const loadRecords = async () => {
    try {
      setLoading(true);
      const url = flaggedOnly ? '/early-warning?flaggedOnly=true' : '/early-warning';
      const data = await apiFetch(url);
      setRecords(data);

      if (['staff', 'admin', 'super_admin'].includes(user?.role)) {
        const stdList = await apiFetch('/users?role=student');
        setStudents(stdList);
        if (stdList.length > 0) setSelectedStudent(stdList[0]._id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleManualSubmit = async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/early-warning', {
        method: 'POST',
        body: JSON.stringify({
          studentId: selectedStudent,
          semester,
          subject,
          attendancePercentage,
          marksPercentage,
          remarks
        })
      });
      setShowManualModal(false);
      loadRecords();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleCsvSubmit = async (e) => {
    e.preventDefault();
    try {
      const lines = csvText.trim().split('\n');
      if (lines.length < 2) {
        alert('Please enter valid CSV data with header');
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim());
      const rows = [];
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',');
        if (parts.length >= 5) {
          const rowObj = {};
          headers.forEach((h, idx) => {
            rowObj[h] = parts[idx] ? parts[idx].trim() : '';
          });
          rows.push(rowObj);
        }
      }

      const res = await apiFetch('/early-warning/bulk-csv', {
        method: 'POST',
        body: JSON.stringify({ rows })
      });

      alert(res.message);
      setShowCsvModal(false);
      loadRecords();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-rose-600" />
            Early-Warning & Low Performer Dashboard
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Automatic flags triggered when Attendance &lt; 75% or Marks &lt; 50%. Alerts sent directly to assigned Mentors.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {['staff', 'admin', 'super_admin'].includes(user?.role) && (
            <>
              <button
                onClick={() => setShowCsvModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                Upload CSV
              </button>

              <button
                onClick={() => setShowManualModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow transition"
              >
                <Plus className="w-4 h-4" />
                Add Record
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filter Toggle */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="flaggedOnly"
            checked={flaggedOnly}
            onChange={(e) => setFlaggedOnly(e.target.checked)}
            className="w-4 h-4 text-rose-600 rounded focus:ring-rose-500"
          />
          <label htmlFor="flaggedOnly" className="text-xs font-bold text-slate-800 cursor-pointer">
            Show Flagged Low Performers Only (&lt;75% Attendance OR &lt;50% Marks)
          </label>
        </div>
        <span className="text-xs font-bold text-slate-500">
          Total Records: {records.length}
        </span>
      </div>

      {/* Table */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading academic records...</div>
      ) : records.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No records match current filter.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold">
              <tr>
                <th className="p-4">Student</th>
                <th className="p-4">Reg No</th>
                <th className="p-4">Subject & Semester</th>
                <th className="p-4">Attendance</th>
                <th className="p-4">Marks</th>
                <th className="p-4">Assigned Mentor</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {records.map(r => (
                <tr key={r._id} className={r.flagged ? 'bg-rose-50/40' : 'hover:bg-slate-50'}>
                  <td className="p-4 font-bold text-slate-900">{r.student?.name}</td>
                  <td className="p-4 text-slate-600">{r.student?.registerNumber || 'N/A'}</td>
                  <td className="p-4 text-slate-800">
                    <div>{r.subject}</div>
                    <div className="text-[10px] text-slate-400">{r.semester}</div>
                  </td>
                  <td className="p-4">
                    <span className={`font-bold ${r.attendancePercentage < 75 ? 'text-rose-600 font-extrabold' : 'text-emerald-700'}`}>
                      {r.attendancePercentage}%
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`font-bold ${r.marksPercentage < 50 ? 'text-rose-600 font-extrabold' : 'text-emerald-700'}`}>
                      {r.marksPercentage}%
                    </span>
                  </td>
                  <td className="p-4 text-slate-700">{r.student?.assignedMentor?.name || 'Unassigned'}</td>
                  <td className="p-4">
                    {r.flagged ? (
                      <span className="px-2.5 py-1 bg-rose-100 text-rose-800 font-extrabold rounded-full text-[10px] border border-rose-300 flex items-center gap-1 w-max">
                        <AlertTriangle className="w-3 h-3" /> Flagged Alert
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[10px] border border-emerald-300 w-max">
                        Satisfactory
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Manual Add Modal */}
      {showManualModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Add Academic & Attendance Record</h2>
              <button onClick={() => setShowManualModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleManualSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Student</label>
                <select
                  value={selectedStudent}
                  onChange={(e) => setSelectedStudent(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                >
                  {students.map(s => (
                    <option key={s._id} value={s._id}>{s.name} ({s.registerNumber || s.email})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
                  <input
                    type="text"
                    required
                    value={semester}
                    onChange={(e) => setSemester(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Attendance %</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    required
                    value={attendancePercentage}
                    onChange={(e) => setAttendancePercentage(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Marks %</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    required
                    value={marksPercentage}
                    onChange={(e) => setMarksPercentage(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Remarks</label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Optional notes"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowManualModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CSV Import Modal */}
      {showCsvModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Bulk Import Academic CSV</h2>
              <button onClick={() => setShowCsvModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleCsvSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">CSV Content (Header: registerNumber,semester,subject,attendancePercentage,marksPercentage,remarks)</label>
                <textarea
                  rows={6}
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 font-mono text-[11px] text-emerald-400 border border-slate-800 rounded-xl"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCsvModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
                >
                  Process CSV Import
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
