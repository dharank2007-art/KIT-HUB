import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { Calendar, Clock, MapPin, Plus, User, CheckCircle2, XCircle } from 'lucide-react';

export const SlotBookingPage = () => {
  const { user } = useAuth();
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showPublishModal, setShowPublishModal] = useState(false);

  // Form states for faculty publishing slot
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('10:00 AM');
  const [endTime, setEndTime] = useState('10:10 AM');
  const [location, setLocation] = useState('Faculty Cabin');
  const [notes, setNotes] = useState('');
  const [bookingReason, setBookingReason] = useState('');
  const [selectedSlotForBooking, setSelectedSlotForBooking] = useState(null);

  useEffect(() => {
    loadSlots();
  }, []);

  const loadSlots = async () => {
    try {
      setLoading(true);
      const data = await apiFetch('/slots');
      setSlots(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePublishSlot = async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/slots', {
        method: 'POST',
        body: JSON.stringify({
          date,
          startTime,
          endTime,
          location,
          notes,
          maxStudents: 1
        })
      });
      setShowPublishModal(false);
      loadSlots();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleBookSlot = async (e) => {
    e.preventDefault();
    if (!selectedSlotForBooking) return;
    try {
      await apiFetch(`/slots/${selectedSlotForBooking._id}/book`, {
        method: 'POST',
        body: JSON.stringify({ reason: bookingReason })
      });
      setSelectedSlotForBooking(null);
      setBookingReason('');
      loadSlots();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleCancel = async (slotId) => {
    if (!window.confirm('Are you sure you want to cancel this slot/booking?')) return;
    try {
      await apiFetch(`/slots/${slotId}/cancel`, { method: 'POST' });
      loadSlots();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            Faculty 1-on-1 Slot Booking (10-Minute Windows)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Faculty publish available consultation slots; students book instant appointments with automatic notification reminders.
          </p>
        </div>

        {['staff', 'admin'].includes(user?.role) && (
          <button
            onClick={() => setShowPublishModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            <Plus className="w-4 h-4" />
            Publish New Slot
          </button>
        )}
      </div>

      {/* Slots List */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading available slots...</div>
      ) : slots.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No meeting slots published yet.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {slots.map(s => {
            const activeBooking = s.bookings?.find(b => b.status === 'Booked');
            const isBookedByMe = activeBooking?.student?._id === user?._id || activeBooking?.student === user?._id;
            const isFull = !!activeBooking;

            return (
              <div key={s._id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 bg-blue-50 text-blue-700 font-bold text-xs rounded-lg border border-blue-200">
                      {s.date}
                    </span>
                    <span className={`px-2.5 py-0.5 font-bold text-[11px] rounded-full border ${isFull ? 'bg-amber-100 text-amber-800 border-amber-300' : 'bg-emerald-100 text-emerald-800 border-emerald-300'}`}>
                      {isFull ? 'Booked' : 'Available'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-900 font-extrabold text-lg">
                    <Clock className="w-5 h-5 text-blue-600" />
                    <span>{s.startTime} - {s.endTime}</span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    <p className="flex items-center gap-1.5 font-semibold text-slate-800">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{s.faculty?.name} ({s.faculty?.department?.code || 'Dept'})</span>
                    </p>
                    <p className="flex items-center gap-1.5 text-slate-500">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{s.location}</span>
                    </p>
                    {s.notes && <p className="italic text-slate-500">"{s.notes}"</p>}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  {user?.role === 'student' && !isFull && (
                    <button
                      onClick={() => setSelectedSlotForBooking(s)}
                      className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
                    >
                      Book 10-Min Slot
                    </button>
                  )}

                  {isBookedByMe && (
                    <div className="space-y-2">
                      <div className="p-2 bg-emerald-50 text-emerald-700 text-xs rounded-lg font-bold text-center">
                        ✓ Booked by You
                      </div>
                      <button
                        onClick={() => handleCancel(s._id)}
                        className="w-full py-1.5 bg-rose-50 text-rose-600 hover:bg-rose-100 font-bold text-xs rounded-lg transition"
                      >
                        Cancel Booking
                      </button>
                    </div>
                  )}

                  {['staff', 'admin', 'super_admin'].includes(user?.role) && (
                    <button
                      onClick={() => handleCancel(s._id)}
                      className="w-full py-1.5 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 font-bold text-xs rounded-lg transition"
                    >
                      Cancel Slot
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Book Slot Modal */}
      {selectedSlotForBooking && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Confirm Slot Booking</h2>
              <button onClick={() => setSelectedSlotForBooking(null)} className="text-slate-400 font-bold">✕</button>
            </div>

            <p className="text-xs text-slate-600">
              Booking 10-minute consultation with <strong>{selectedSlotForBooking.faculty?.name}</strong> on {selectedSlotForBooking.date} at {selectedSlotForBooking.startTime}.
            </p>

            <form onSubmit={handleBookSlot} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Reason for Meeting</label>
                <textarea
                  required
                  rows={3}
                  value={bookingReason}
                  onChange={(e) => setBookingReason(e.target.value)}
                  placeholder="Brief explanation (e.g. Project doubt review / Attendance clarification)..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedSlotForBooking(null)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Publish Slot Modal (Faculty) */}
      {showPublishModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Publish 10-Minute Slot</h2>
              <button onClick={() => setShowPublishModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handlePublishSlot} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Start Time</label>
                  <input
                    type="text"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    placeholder="10:00 AM"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">End Time</label>
                  <input
                    type="text"
                    required
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    placeholder="10:10 AM"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Meeting Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Cabin 204"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Notes / Instructions</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Bring lab record"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPublishModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  Publish Slot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
