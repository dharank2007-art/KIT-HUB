import React, { useState } from 'react';
import { apiFetch } from '../services/api';
import { FileSpreadsheet, Upload, CheckCircle, AlertCircle } from 'lucide-react';

const parseCsv = (text) => {
  const records = [];
  let record = [];
  let field = '';
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        field += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === ',' && !quoted) {
      record.push(field.trim());
      field = '';
    } else if ((character === '\n' || character === '\r') && !quoted) {
      if (character === '\r' && text[index + 1] === '\n') index += 1;
      record.push(field.trim());
      if (record.some(Boolean)) records.push(record);
      record = [];
      field = '';
    } else {
      field += character;
    }
  }

  if (quoted) throw new Error('CSV contains an unclosed quoted field');
  record.push(field.trim());
  if (record.some(Boolean)) records.push(record);
  if (records.length < 2) throw new Error('Please provide CSV content with a header and at least one row');

  const headers = records[0].map((header) => header.trim());
  if (headers.some((header) => !header)) throw new Error('CSV headers cannot be empty');
  return records.slice(1).map((values) => Object.fromEntries(
    headers.map((header, index) => [header, values[index] || ''])
  ));
};

export const BulkUserUploadPage = () => {
  const [csvContent, setCsvContent] = useState(
`name,email,role,department,registerNumber,employeeId,phone,password
Prof. Madhavan,madhavan@kit.edu,staff,CSE,,EMP0109,+91 9876543299,Welcome@123
Siddharth M,siddharth@kit.edu,student,CSE,731621104011,,+91 9000000011,Welcome@123`
  );
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      const rows = parseCsv(csvContent);

      const res = await apiFetch('/users/bulk-csv', {
        method: 'POST',
        body: JSON.stringify({ rows })
      });

      setResult(res);
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
          Bulk CSV Faculty & Student Account Generator (Phase 1)
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Super Admin tool to bulk create faculty and student accounts with automatic department resolution and default initial passwords.
        </p>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <form onSubmit={handleUpload} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              CSV Data Input (Header: name, email, role, department, registerNumber, employeeId, phone, password)
            </label>
            <textarea
              rows={10}
              value={csvContent}
              onChange={(e) => setCsvContent(e.target.value)}
              className="w-full px-4 py-3 bg-slate-950 font-mono text-xs text-emerald-400 border border-slate-800 rounded-xl focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
          >
            <Upload className="w-4 h-4" />
            {loading ? 'Processing Bulk Create...' : 'Process Bulk Account Import'}
          </button>
        </form>

        {result && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              {result.message}
            </h3>
            <p className="text-slate-600 font-semibold">Created Accounts ({result.createdCount}):</p>
            <div className="flex flex-wrap gap-1">
              {result.createdUsers?.map((u, i) => (
                <span key={i} className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono text-[10px] rounded">
                  {u}
                </span>
              ))}
            </div>

            {result.errors?.length > 0 && (
              <div className="pt-2 text-rose-600">
                <p className="font-bold">Errors / Warnings ({result.errors.length}):</p>
                {result.errors.map((err, i) => (
                  <p key={i} className="text-[11px]">• Line {err.line} ({err.email}): {err.error}</p>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
};
