import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiFetch } from '../services/api';
import { ArrowRight, UserPlus } from 'lucide-react';

const initialValues = {
  name: '', email: '', password: '', registerNumber: '', department: '', className: '',
  bloodGroup: '', phone: '', linkedin: '', portfolio: ''
};

export const Register = () => {
  const [values, setValues] = useState(initialValues);
  const [departments, setDepartments] = useState([]);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    apiFetch('/departments/public').then(setDepartments).catch(err => setError(err.message));
  }, []);

  const update = (event) => setValues(previous => ({ ...previous, [event.target.name]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      await apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(values) });
      setSubmitted(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-4 py-10">
      <section className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-6 sm:p-8 shadow-2xl">
        <div className="mb-6 flex items-center gap-3">
          <UserPlus className="h-7 w-7 text-amber-400" />
          <div>
            <h1 className="text-2xl font-bold">KIT College Portal</h1>
            <p className="text-sm text-slate-400">Student account registration</p>
          </div>
        </div>

        {submitted ? (
          <div className="space-y-4" role="status">
            <p className="rounded-lg border border-emerald-700 bg-emerald-950/50 p-4 text-sm text-emerald-200">
              Registration submitted. An administrator must approve your account before you can sign in.
            </p>
            <Link to="/login" className="inline-flex items-center gap-2 text-sm font-semibold text-amber-300 hover:text-amber-200">
              Return to sign in <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <p className="rounded-lg border border-rose-700 bg-rose-950/50 p-3 text-sm text-rose-200" role="alert">{error}</p>}
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="text-xs font-semibold text-slate-300">Full name
                <input required name="name" value={values.name} onChange={update} autoComplete="name" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300">College email
                <input required type="email" name="email" value={values.email} onChange={update} autoComplete="email" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300">Password
                <input required type="password" minLength="6" name="password" value={values.password} onChange={update} autoComplete="new-password" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300">Roll number
                <input required name="registerNumber" value={values.registerNumber} onChange={update} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300">Department
                <select required name="department" value={values.department} onChange={update} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white">
                  <option value="">Select department</option>
                  {departments.map(department => <option key={department._id} value={department._id}>{department.code} - {department.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-semibold text-slate-300">Class / section
                <input required name="className" value={values.className} onChange={update} placeholder="III-A" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300">Blood group
                <select required name="bloodGroup" value={values.bloodGroup} onChange={update} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white">
                  <option value="">Select blood group</option>
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(group => <option key={group}>{group}</option>)}
                </select>
              </label>
              <label className="text-xs font-semibold text-slate-300">Phone
                <input name="phone" value={values.phone} onChange={update} autoComplete="tel" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300 sm:col-span-2">LinkedIn profile (required)
                <input required type="url" name="linkedin" value={values.linkedin} onChange={update} placeholder="https://www.linkedin.com/in/your-profile" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
              <label className="text-xs font-semibold text-slate-300 sm:col-span-2">Portfolio URL (optional)
                <input type="url" name="portfolio" value={values.portfolio} onChange={update} placeholder="https://example.com" className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white" />
              </label>
            </div>
            <button disabled={loading || departments.length === 0} className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-3 text-sm font-bold text-white hover:bg-blue-500 disabled:opacity-50">
              {loading ? 'Submitting...' : 'Submit registration'} <ArrowRight className="h-4 w-4" />
            </button>
            <p className="text-center text-sm text-slate-400">Already registered? <Link to="/login" className="font-semibold text-amber-300 hover:underline">Sign in</Link></p>
          </form>
        )}
      </section>
    </main>
  );
};