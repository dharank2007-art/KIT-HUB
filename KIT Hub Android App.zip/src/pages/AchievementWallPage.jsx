import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch, backendUrl } from '../services/api';
import { Trophy, Heart, Plus, Image, Sparkles } from 'lucide-react';

export const AchievementWallPage = () => {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Academic');
  const [image, setImage] = useState('');

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = async () => {
    try {
      setLoading(true);
      const data = await apiFetch('/achievements');
      setAchievements(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePost = async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/achievements', {
        method: 'POST',
        body: JSON.stringify({ title, description, category, image })
      });
      setTitle('');
      setDescription('');
      setImage('');
      setShowModal(false);
      loadAchievements();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleLike = async (id) => {
    try {
      await apiFetch(`/achievements/${id}/like`, { method: 'POST' });
      loadAchievements();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-500" />
            KIT Student & Faculty Achievement Wall
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Celebrate hackathon wins, research paper publications, sports trophies, and academic accolades!
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          Share Achievement
        </button>
      </div>

      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading Achievement Wall...</div>
      ) : achievements.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No achievements posted yet. Be the first to share your trophy or certificate!
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map(a => {
            const hasLiked = a.likes?.includes(user?._id);
            return (
              <div key={a._id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition">
                {a.image ? (
                  <div className="h-48 w-full bg-slate-900 overflow-hidden">
                    <img src={backendUrl(a.image)} alt={a.title} className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="h-24 bg-gradient-to-r from-amber-500 to-amber-600 flex items-center justify-center text-white">
                    <Trophy className="w-10 h-10 text-amber-200" />
                  </div>
                )}

                <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded">
                        {a.category}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(a.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <h3 className="font-bold text-slate-900 text-base">{a.title}</h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{a.description}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[10px]">
                        {a.author?.name?.charAt(0) || 'U'}
                      </div>
                      <span className="font-semibold text-slate-800">{a.author?.name}</span>
                    </div>

                    <button
                      onClick={() => handleLike(a._id)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition ${
                        hasLiked 
                          ? 'bg-rose-100 text-rose-600' 
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${hasLiked ? 'fill-current text-rose-600' : ''}`} />
                      <span>{a.likes?.length || 0}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Post Achievement</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handlePost} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                >
                  <option value="Academic">Academic Distinction</option>
                  <option value="Hackathon">Hackathon & Coding</option>
                  <option value="Sports">Sports & Athletics</option>
                  <option value="Cultural">Cultural & Arts</option>
                  <option value="Research">Research & Paper Publication</option>
                  <option value="Other">Other Achievement</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Achievement Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 1st Place in State Level AI Hackathon"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Share details about your accomplishment..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Certificate / Photo URL (Optional)</label>
                <input
                  type="text"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  placeholder="http://... or upload link"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow"
                >
                  Post Achievement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
