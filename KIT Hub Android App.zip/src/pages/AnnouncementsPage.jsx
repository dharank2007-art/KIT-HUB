import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch, backendUrl } from '../services/api';
import { Megaphone, FileText, Plus, Paperclip, Shield, Users } from 'lucide-react';

export const AnnouncementsPage = () => {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('announcements'); // 'announcements' | 'community'
  const [showModal, setShowModal] = useState(false);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isGlobal, setIsGlobal] = useState(true);
  const [attachmentUrl, setAttachmentUrl] = useState('');

  useEffect(() => {
    loadAnnouncements();
  }, [activeTab]);

  const loadAnnouncements = async () => {
    try {
      setLoading(true);
      const isCommunityBoard = activeTab === 'community';
      const url = `/announcements?isCommunityBoard=${isCommunityBoard}`;
      const data = await apiFetch(url);
      setAnnouncements(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const isCommunityBoard = activeTab === 'community';
      await apiFetch('/announcements', {
        method: 'POST',
        body: JSON.stringify({
          title,
          content,
          isGlobal: isCommunityBoard || isGlobal,
          isCommunityBoard,
          attachments: attachmentUrl ? [attachmentUrl] : []
        })
      });
      setTitle('');
      setContent('');
      setAttachmentUrl('');
      setShowModal(false);
      loadAnnouncements();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-blue-600" />
            Announcements, Circular PDFs & Community Board
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Departmental notices, PDF circular attachments, and super-admin campus community broadcasts.
          </p>
        </div>

        {['staff', 'admin', 'super_admin'].includes(user?.role) && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            <Plus className="w-4 h-4" />
            {activeTab === 'community' ? 'Post to Community Board' : 'Post Announcement'}
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('announcements')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'announcements' 
              ? 'bg-slate-900 text-white shadow' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          Department & Campus Circulars
        </button>

        <button
          onClick={() => setActiveTab('community')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
            activeTab === 'community' 
              ? 'bg-purple-900 text-white shadow' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          Super-Admin Community Board
        </button>
      </div>

      {/* List */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading posts...</div>
      ) : announcements.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No posts available in this section.
        </div>
      ) : (
        <div className="space-y-4">
          {announcements.map(ann => (
            <div key={ann._id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full ${
                    ann.isCommunityBoard 
                      ? 'bg-purple-100 text-purple-800 border border-purple-300' 
                      : ann.isGlobal 
                        ? 'bg-blue-100 text-blue-800 border border-blue-300' 
                        : 'bg-slate-100 text-slate-700 border border-slate-200'
                  }`}>
                    {ann.isCommunityBoard ? 'Community Board' : ann.isGlobal ? 'Global Broadcast' : ann.department?.code || 'Department'}
                  </span>
                  <span className="text-xs font-bold text-slate-700">By {ann.author?.name}</span>
                </div>
                <span className="text-xs text-slate-400">
                  {new Date(ann.createdAt).toLocaleDateString()}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 text-base">{ann.title}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed whitespace-pre-line">{ann.content}</p>
              </div>

              {ann.attachments?.length > 0 && (
                <div className="pt-2 border-t border-slate-100 space-y-1">
                  <p className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                    <Paperclip className="w-3.5 h-3.5 text-blue-600" /> Circular PDF Attachments:
                  </p>
                  {ann.attachments.map((att, idx) => (
                    <a
                      key={idx}
                      href={backendUrl(att)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-blue-50 text-blue-700 border border-slate-200 rounded-lg text-xs font-semibold transition"
                    >
                      <FileText className="w-4 h-4 text-rose-600" />
                      <span>Download / View Circular PDF #{idx + 1}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">
                {activeTab === 'community' ? 'Post to Super-Admin Community Board' : 'Create Circular / Announcement'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Circular title..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Content / Message</label>
                <textarea
                  required
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Full text details..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              {activeTab !== 'community' && user?.role === 'super_admin' && (
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="glob"
                    checked={isGlobal}
                    onChange={(e) => setIsGlobal(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <label htmlFor="glob" className="text-xs font-semibold text-slate-700">Global Campus Broadcast</label>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Circular PDF / Image URL (Optional)</label>
                <input
                  type="text"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  placeholder="http://... or /uploads/circular.pdf"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl shadow"
                >
                  Publish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
