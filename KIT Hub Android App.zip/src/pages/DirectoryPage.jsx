import React, { useState, useEffect } from 'react';
import { apiFetch } from '../services/api';
import { Users, Search, Mail, Phone, Clock, Shield } from 'lucide-react';

export const DirectoryPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');

  useEffect(() => {
    loadUsers();
  }, [search, roleFilter]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      let query = [];
      if (search) query.push(`search=${encodeURIComponent(search)}`);
      if (roleFilter) query.push(`role=${roleFilter}`);
      const url = `/users${query.length > 0 ? '?' + query.join('&') : ''}`;
      const data = await apiFetch(url);
      setUsers(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const roleBadges = {
    super_admin: 'bg-purple-100 text-purple-800 border-purple-300',
    admin: 'bg-blue-100 text-blue-800 border-blue-300',
    staff: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    student: 'bg-amber-100 text-amber-800 border-amber-300'
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Users className="w-6 h-6 text-blue-600" />
          Campus Directory
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Find contact details and department allocations for Super Admin, HODs, Faculty, and Students.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, register number, or employee ID..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
        >
          <option value="">All Roles</option>
          <option value="super_admin">Super Admin</option>
          <option value="admin">HOD (Department Head)</option>
          <option value="staff">Faculty (Staff)</option>
          <option value="student">Student</option>
        </select>
      </div>

      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading directory...</div>
      ) : users.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No user profiles found.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.map(u => (
            <div key={u._id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-0.5 font-bold text-[10px] rounded-full border ${roleBadges[u.role]}`}>
                  {u.role === 'admin' ? 'HOD' : u.role === 'staff' ? 'Faculty' : u.role.replace('_', ' ')}
                </span>
                <span className="text-[10px] text-slate-400">
                  {u.department?.code || 'Campus'}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-extrabold flex items-center justify-center text-sm shadow-inner">
                  {u.name?.charAt(0) || 'U'}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{u.name}</h3>
                  <p className="text-[11px] text-slate-500">
                    {u.registerNumber ? `Reg: ${u.registerNumber}` : u.designation || (u.employeeId ? `Emp ID: ${u.employeeId}` : '')}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1 text-xs text-slate-600">
                <p className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <a href={`mailto:${u.email}`} className="text-blue-600 hover:underline truncate">{u.email}</a>
                </p>
                {u.phone && (
                  <p className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{u.phone}</span>
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
