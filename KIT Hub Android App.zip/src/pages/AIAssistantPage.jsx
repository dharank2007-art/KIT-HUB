import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { Bot, Send, Sparkles, HelpCircle, Plus, Trash2, ArrowRight, Pencil } from 'lucide-react';

export const AIAssistantPage = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: '🤖 Hello! I am the official KIT College AI Assistant (powered by Claude API). How can I help you today with Leave, OD, Faculty contacts, or Regulations?',
      source: 'KIT AI'
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [faqs, setFaqs] = useState([]);
  const [showAddFaq, setShowAddFaq] = useState(false);
  const [editingFaqId, setEditingFaqId] = useState(null);

  // FAQ form
  const [newQ, setNewQ] = useState('');
  const [newA, setNewA] = useState('');
  const [category, setCategory] = useState('General');

  useEffect(() => {
    loadFaqs();
  }, []);

  const loadFaqs = async () => {
    try {
      const data = await apiFetch('/ai/faqs');
      setFaqs(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSendQuery = async (e, textOverride) => {
    if (e) e.preventDefault();
    const queryText = textOverride || inputQuery;
    if (!queryText.trim()) return;

    const userMsg = { sender: 'user', text: queryText };
    setMessages(prev => [...prev, userMsg]);
    if (!textOverride) setInputQuery('');
    setLoading(true);

    try {
      const res = await apiFetch('/ai/query', {
        method: 'POST',
        body: JSON.stringify({ query: queryText })
      });

      setMessages(prev => [
        ...prev,
        { sender: 'ai', text: res.answer, source: res.source }
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        { sender: 'ai', text: 'Sorry, I ran into an issue getting the response. Please try again.', source: 'Error' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddFaq = async (e) => {
    e.preventDefault();
    try {
      await apiFetch(editingFaqId ? `/ai/faqs/${editingFaqId}` : '/ai/faqs', {
        method: editingFaqId ? 'PUT' : 'POST',
        body: JSON.stringify({ question: newQ, answer: newA, category })
      });
      setNewQ('');
      setNewA('');
      setEditingFaqId(null);
      setShowAddFaq(false);
      loadFaqs();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleEditFaq = (faq) => {
    setEditingFaqId(faq._id);
    setNewQ(faq.question);
    setNewA(faq.answer);
    setCategory(faq.category || 'General');
    setShowAddFaq(true);
  };

  const handleDeleteFaq = async (id) => {
    if (!window.confirm('Delete FAQ item?')) return;
    try {
      await apiFetch(`/ai/faqs/${id}`, { method: 'DELETE' });
      loadFaqs();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Bot className="w-6 h-6 text-amber-500" />
            AI Assistant & Knowledge Base (Claude API)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Instant answers for OD/Leave procedures, college FAQs, and faculty contact routing.
          </p>
        </div>

        {user?.role === 'super_admin' && (
          <button
            onClick={() => setShowAddFaq(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition"
          >
            <Plus className="w-4 h-4" />
            Add College FAQ
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: AI Interactive Chat */}
        <div className="lg:col-span-2 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-xl flex flex-col h-[600px]">
          
          <div className="p-4 border-b border-slate-800 bg-slate-950/60 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-xs text-slate-200">Interactive Claude AI Assistant</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
              Active Mode
            </span>
          </div>

          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                  msg.sender === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none' 
                    : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'
                }`}>
                  <p className="whitespace-pre-line">{msg.text}</p>
                  {msg.source && (
                    <p className="text-[10px] text-slate-400 mt-2 text-right italic">Source: {msg.source}</p>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-800 p-3 rounded-2xl text-xs text-amber-300 animate-pulse border border-slate-700">
                  Claude AI is thinking...
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSendQuery} className="p-3 border-t border-slate-800 bg-slate-950/80 rounded-b-2xl flex gap-2">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask anything about Leave, OD, FAQs, or Faculty..."
              className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow text-xs flex items-center gap-1 transition"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>

        {/* Right 1 Col: FAQ List */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-600" />
            Official FAQs Knowledge Base ({faqs.length})
          </h2>

          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {faqs.map(f => (
              <div key={f._id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="line-clamp-1">{f.question}</span>
                  {user?.role === 'super_admin' && (
                    <span className="flex items-center gap-2">
                      <button onClick={() => handleEditFaq(f)} className="text-slate-500 hover:text-blue-700" title="Edit FAQ">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleDeleteFaq(f._id)} className="text-rose-500 hover:text-rose-700" title="Delete FAQ">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </span>
                  )}
                </div>
                <p className="text-slate-600 leading-relaxed">{f.answer}</p>
                <button
                  onClick={() => handleSendQuery(null, f.question)}
                  className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-1 pt-1"
                >
                  Ask AI this question <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Add FAQ Modal (Super Admin) */}
      {showAddFaq && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">{editingFaqId ? 'Edit FAQ Item' : 'Add FAQ Item'}</h2>
              <button onClick={() => { setShowAddFaq(false); setEditingFaqId(null); }} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleAddFaq} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="e.g. Attendance & OD"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Question</label>
                <input
                  type="text"
                  required
                  value={newQ}
                  onChange={(e) => setNewQ(e.target.value)}
                  placeholder="e.g. What is the procedure for Bonafide certificate?"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Answer</label>
                <textarea
                  required
                  rows={4}
                  value={newA}
                  onChange={(e) => setNewA(e.target.value)}
                  placeholder="Official answer text..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowAddFaq(false); setEditingFaqId(null); }}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow"
                >
                  {editingFaqId ? 'Update FAQ' : 'Save FAQ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
