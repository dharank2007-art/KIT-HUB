import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch, backendUrl } from '../services/api';
import { MessageCircle, Send, Paperclip, Mic, User, Image } from 'lucide-react';

export const ChatPage = () => {
  const { user } = useAuth();
  const [directory, setDirectory] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [recording, setRecording] = useState(false);

  useEffect(() => {
    loadDirectory();
  }, []);

  useEffect(() => {
    if (selectedUser) {
      loadMessages(selectedUser._id);
    }
  }, [selectedUser]);

  const loadDirectory = async () => {
    try {
      const users = await apiFetch('/users');
      const isStaffSide = ['super_admin', 'admin', 'staff'].includes(user?.role);
      const ownDepartment = user?.department?._id || user?.department;
      const others = users.filter(contact => {
        if (contact._id === user?._id) return false;
        const isValidRolePair = isStaffSide
          ? contact.role === 'student'
          : ['super_admin', 'admin', 'staff'].includes(contact.role);
        const contactDepartment = contact.department?._id || contact.department;
        const sameDepartment = user?.role === 'super_admin' || contact.role === 'super_admin' || ownDepartment?.toString() === contactDepartment?.toString();
        return isValidRolePair && sameDepartment;
      });
      setDirectory(others);
      if (others.length > 0) setSelectedUser(others[0]);
    } catch (e) {
      console.error(e);
    }
  };

  const loadMessages = async (targetId) => {
    try {
      const data = await apiFetch(`/chat/${targetId}`);
      setMessages(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!selectedUser || (!newMessage.trim() && !attachmentUrl)) return;

    try {
      await apiFetch('/chat', {
        method: 'POST',
        body: JSON.stringify({
          recipientId: selectedUser._id,
          message: newMessage,
          attachments: attachmentUrl ? [attachmentUrl] : []
        })
      });

      setNewMessage('');
      setAttachmentUrl('');
      loadMessages(selectedUser._id);
    } catch (err) {
      alert(err.message);
    }
  };

  const handleSimulateVoiceNote = async () => {
    if (!selectedUser) return;
    setRecording(true);
    setTimeout(async () => {
      setRecording(false);
      try {
        await apiFetch('/chat', {
          method: 'POST',
          body: JSON.stringify({
            recipientId: selectedUser._id,
            message: '🎤 [Voice Note Query] 0:15 sec audio attachment',
            attachments: ['/uploads/voice-note-demo.mp3']
          })
        });
        loadMessages(selectedUser._id);
      } catch (e) {
        console.error(e);
      }
    }, 1500);
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <MessageCircle className="w-6 h-6 text-blue-600" />
          1:1 Direct Chat & Voice Notes
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Chat with faculty, mentors, HODs, and peers with attachment and voice query support.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-3 min-h-[550px] overflow-hidden">
        
        {/* Left Col: Contact Directory List */}
        <div className="border-r border-slate-200 p-4 space-y-3 bg-slate-50">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">Select Contact</h2>
          <div className="space-y-1 max-h-[480px] overflow-y-auto">
            {directory.map(u => (
              <button
                key={u._id}
                onClick={() => setSelectedUser(u)}
                className={`w-full text-left p-3 rounded-xl transition flex items-center gap-3 ${
                  selectedUser?._id === u._id 
                    ? 'bg-blue-600 text-white shadow font-semibold' 
                    : 'bg-white hover:bg-slate-100 text-slate-800 border border-slate-200'
                }`}
              >
                <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs">
                  {u.name?.charAt(0) || 'U'}
                </div>
                <div className="truncate text-xs">
                  <div className="font-bold truncate">{u.name}</div>
                  <div className={`text-[10px] ${selectedUser?._id === u._id ? 'text-blue-100' : 'text-slate-500'}`}>
                    {u.role === 'admin' ? 'HOD' : u.role === 'staff' ? 'Faculty' : u.role} • {u.department?.code || 'KIT'}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right 2 Cols: Active Chat Feed */}
        <div className="md:col-span-2 flex flex-col justify-between h-[550px]">
          
          {selectedUser ? (
            <>
              <div className="p-4 border-b border-slate-200 bg-white flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{selectedUser.name}</h3>
                  <p className="text-xs text-slate-500">
                    {selectedUser.email} • {selectedUser.department?.name || 'Department'}
                  </p>
                </div>
              </div>

              {/* Chat Message Scroll */}
              <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
                {messages.length === 0 ? (
                  <div className="text-center text-xs text-slate-400 py-12">
                    No conversation history. Send a message to start chatting!
                  </div>
                ) : (
                  messages.map(m => {
                    const isMine = m.sender?._id === user?._id || m.sender === user?._id;
                    return (
                      <div key={m._id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-3 rounded-2xl text-xs space-y-1 ${
                          isMine 
                            ? 'bg-blue-600 text-white rounded-br-none' 
                            : 'bg-white text-slate-800 rounded-bl-none border border-slate-200 shadow-sm'
                        }`}>
                          <p>{m.message}</p>
                          {m.attachments?.map((att, idx) => (
                            <a key={idx} href={backendUrl(att)} target="_blank" rel="noreferrer" className="block underline text-[11px]">
                              Attachment #{idx + 1}
                            </a>
                          ))}
                          <p className={`text-[10px] text-right ${isMine ? 'text-blue-200' : 'text-slate-400'}`}>
                            {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Input Bar */}
              <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSimulateVoiceNote}
                  disabled={recording}
                  className={`p-2.5 rounded-xl transition ${recording ? 'bg-rose-600 text-white animate-pulse' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'}`}
                  title="Voice Note Query"
                >
                  <Mic className="w-4 h-4" />
                </button>

                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />

                <button
                  type="submit"
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs">Select a user to begin chatting.</div>
          )}

        </div>

      </div>

    </div>
  );
};
