import React, { useEffect, useState } from 'react';
import { apiFetch } from '../services/api';
import { Search, HeartPulse, Send, Check, X } from 'lucide-react';

const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const BloodFinderPage = () => {
  const [bloodGroup, setBloodGroup] = useState('');
  const [department, setDepartment] = useState('');
  const [departments, setDepartments] = useState([]);
  const [donors, setDonors] = useState([]);
  const [receivedRequests, setReceivedRequests] = useState([]);
  const [sentRequests, setSentRequests] = useState([]);
  const [selectedDonor, setSelectedDonor] = useState(null);
  const [requestLocation, setRequestLocation] = useState('');
  const [urgency, setUrgency] = useState('normal');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      apiFetch('/departments'),
      apiFetch('/blood-requests/received'),
      apiFetch('/blood-requests/sent')
    ])
      .then(([departmentList, received, sent]) => {
        setDepartments(departmentList);
        setReceivedRequests(received);
        setSentRequests(sent);
      })
      .catch(err => setError(err.message));
  }, []);

  useEffect(() => {
    setLoading(true);
    setError('');
    const params = new URLSearchParams();
    if (bloodGroup) params.set('bloodGroup', bloodGroup);
    if (department) params.set('department', department);
    apiFetch(`/users/blood-donors${params.size ? `?${params}` : ''}`)
      .then(setDonors)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [bloodGroup, department]);

  const sendRequest = async event => {
    event.preventDefault();
    if (!selectedDonor) return;
    setSubmitting(true);
    setError('');
    try {
      const request = await apiFetch('/blood-requests', {
        method: 'POST',
        body: JSON.stringify({
          donorId: selectedDonor._id,
          location: requestLocation,
          urgency,
          message
        })
      });
      setSentRequests(current => [request, ...current]);
      setSelectedDonor(null);
      setRequestLocation('');
      setMessage('');
      setUrgency('normal');
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const updateRequest = async (requestId, status) => {
    setError('');
    try {
      await apiFetch(`/blood-requests/${requestId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      setReceivedRequests(current => current.map(request =>
        request._id === requestId ? { ...request, status } : request
      ));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3 border-b border-slate-200 pb-4">
        <HeartPulse className="h-6 w-6 text-rose-700" />
        <div><h1 className="text-xl font-bold text-slate-900">Blood Group Finder</h1><p className="text-sm text-slate-500">Find approved student donors by blood group and department.</p></div>
      </header>
      <div className="flex flex-wrap gap-4">
        <label className="flex items-center gap-3 text-sm font-semibold text-slate-700">
          <span>Blood group</span>
          <select value={bloodGroup} onChange={event => setBloodGroup(event.target.value)} className="min-w-40 rounded-md border border-slate-300 bg-white px-3 py-2">
            <option value="">All groups</option>{bloodGroups.map(group => <option key={group}>{group}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-3 text-sm font-semibold text-slate-700">
          <span>Department / location</span>
          <select value={department} onChange={event => setDepartment(event.target.value)} className="min-w-48 rounded-md border border-slate-300 bg-white px-3 py-2">
            <option value="">All locations</option>
            {departments.map(item => <option key={item._id} value={item._id}>{item.name}</option>)}
          </select>
        </label>
      </div>
      {error && <p className="text-sm text-rose-700" role="alert">{error}</p>}
      {loading ? <p className="py-8 text-center text-sm text-slate-500">Searching...</p> : donors.length === 0 ? (
        <p className="border-y border-slate-200 py-8 text-center text-sm text-slate-500">No matching approved profiles.</p>
      ) : (
        <div className="divide-y divide-slate-200 border-y border-slate-200">
          {donors.map(donor => <article key={donor._id} className="flex items-center justify-between gap-4 py-4">
            <div><h2 className="font-bold text-slate-900">{donor.name}</h2><p className="text-xs text-slate-500">{donor.department?.code} · {donor.className || donor.registerNumber}</p></div>
            <div className="flex items-center gap-3">
              <span className="rounded-md border border-rose-200 bg-rose-50 px-3 py-1.5 text-sm font-extrabold text-rose-800">{donor.bloodGroup}</span>
              <button type="button" onClick={() => setSelectedDonor(donor)} className="inline-flex items-center gap-2 rounded-md bg-rose-700 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-800">
                <Send className="h-4 w-4" />Request
              </button>
            </div>
          </article>)}
        </div>
      )}
      {selectedDonor && <form onSubmit={sendRequest} className="space-y-4 border-y border-slate-200 py-5">
        <h2 className="font-bold text-slate-900">Request {selectedDonor.bloodGroup} blood from {selectedDonor.name}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1 text-sm font-semibold text-slate-700">
            <span>Request location</span>
            <input required maxLength={120} value={requestLocation} onChange={event => setRequestLocation(event.target.value)} placeholder="Hospital or campus location" className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-normal" />
          </label>
          <label className="space-y-1 text-sm font-semibold text-slate-700">
            <span>Urgency</span>
            <select value={urgency} onChange={event => setUrgency(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2">
              <option value="normal">Normal</option><option value="urgent">Urgent</option><option value="critical">Critical</option>
            </select>
          </label>
        </div>
        <label className="block space-y-1 text-sm font-semibold text-slate-700">
          <span>Message <span className="font-normal text-slate-500">(optional)</span></span>
          <textarea maxLength={500} rows={3} value={message} onChange={event => setMessage(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-normal" />
        </label>
        <div className="flex gap-2">
          <button disabled={submitting} className="inline-flex items-center gap-2 rounded-md bg-rose-700 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-800 disabled:opacity-60"><Send className="h-4 w-4" />{submitting ? 'Sending...' : 'Send request'}</button>
          <button type="button" onClick={() => setSelectedDonor(null)} className="rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Cancel</button>
        </div>
      </form>}
      <section className="space-y-3">
        <h2 className="text-lg font-bold text-slate-900">Requests received</h2>
        {receivedRequests.length === 0 ? <p className="text-sm text-slate-500">No donor requests received.</p> : receivedRequests.map(request => <article key={request._id} className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 py-3">
          <div>
            <p className="font-semibold text-slate-900">{request.bloodGroup} · {request.urgency} · {request.location}</p>
            <p className="text-sm text-slate-500">From {request.requester?.name}{request.message ? `: ${request.message}` : ''}</p>
          </div>
          <div className="flex items-center gap-2">
            {request.status === 'pending' ? <>
              <button type="button" onClick={() => updateRequest(request._id, 'accepted')} title="Accept request" className="rounded-md border border-emerald-300 p-2 text-emerald-800 hover:bg-emerald-50"><Check className="h-4 w-4" /></button>
              <button type="button" onClick={() => updateRequest(request._id, 'declined')} title="Decline request" className="rounded-md border border-slate-300 p-2 text-slate-600 hover:bg-slate-50"><X className="h-4 w-4" /></button>
            </> : <span className="text-sm font-semibold capitalize text-slate-600">{request.status}</span>}
          </div>
        </article>)}
      </section>
      <section className="space-y-3">
        <h2 className="text-lg font-bold text-slate-900">Requests sent</h2>
        {sentRequests.length === 0 ? <p className="text-sm text-slate-500">No requests sent.</p> : sentRequests.map(request => <article key={request._id} className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 py-3">
          <div>
            <p className="font-semibold text-slate-900">{request.bloodGroup} · {request.urgency} · {request.location}</p>
            <p className="text-sm text-slate-500">To {request.donor?.name}</p>
          </div>
          <span className="text-sm font-semibold capitalize text-slate-600">{request.status}</span>
        </article>)}
      </section>
      <p className="flex items-center gap-2 text-xs text-slate-500"><Search className="h-4 w-4" />Only approved student donor profiles are listed.</p>
    </div>
  );
};