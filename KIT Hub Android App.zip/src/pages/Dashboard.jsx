import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../services/api';
import { 
  Ticket, 
  Clock, 
  Calendar, 
  HelpCircle, 
  AlertTriangle, 
  FileText, 
  Users, 
  CheckCircle, 
  Bot, 
  ArrowRight,
  Sparkles,
  UserRoundCheck,
  HeartPulse,
  MessageCircle,
  Megaphone,
  UserRound,
  X,
  RefreshCw
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Dashboard = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [stats, setStats] = useState({
    pendingTickets: null,
    freeFacultyCount: null,
    flaggedWarningCount: null,
    openDoubtsCount: null
  });
  const [facultyAvail, setFacultyAvail] = useState('Free');
  const [downloadingReport, setDownloadingReport] = useState(false);
  const [approvalCounts, setApprovalCounts] = useState({ pending: null, approved: null, rejected: null });
  const [pendingRegistrations, setPendingRegistrations] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const refreshInFlight = useRef(false);

  useEffect(() => {
    if (!user?._id) return undefined;

    const refreshWhenVisible = () => {
      if (document.visibilityState === 'visible') loadDashboardData();
    };

    loadDashboardData();
    const interval = window.setInterval(refreshWhenVisible, 60_000);
    window.addEventListener('focus', refreshWhenVisible);
    document.addEventListener('visibilitychange', refreshWhenVisible);

    return () => {
      window.clearInterval(interval);
      window.removeEventListener('focus', refreshWhenVisible);
      document.removeEventListener('visibilitychange', refreshWhenVisible);
    };
  }, [user?._id, user?.role]);

  const loadDashboardData = async () => {
    if (refreshInFlight.current) return;
    refreshInFlight.current = true;
    setIsRefreshing(true);
    try {
    const isAdmin = ['admin', 'super_admin'].includes(user?.role);
    const paths = [
      '/tickets',
      '/availability',
      '/early-warning?flaggedOnly=true',
      '/doubts?resolved=false',
      ...(isAdmin ? ['pending', 'approved', 'rejected'].map(status => `/users/approvals?status=${status}`) : [])
    ];
    const results = await Promise.allSettled(paths.map(path => apiFetch(path)));
    const failures = [];
    let successfulLoads = 0;
    const nextStats = {};
    const [ticketsResult, availabilityResult, warningsResult, doubtsResult] = results;

    if (ticketsResult.status === 'fulfilled' && Array.isArray(ticketsResult.value)) {
      nextStats.pendingTickets = ticketsResult.value.filter(ticket => ticket.status === 'Pending').length;
      successfulLoads += 1;
    } else failures.push('tickets');

    if (availabilityResult.status === 'fulfilled' && Array.isArray(availabilityResult.value)) {
      nextStats.freeFacultyCount = availabilityResult.value.filter(item => item.status === 'Free' || item.status === 'In cabin').length;
      successfulLoads += 1;
      if (['staff', 'admin'].includes(user?.role)) {
        const myAvailability = availabilityResult.value.find(item => item.faculty?._id === user?._id || item.faculty === user?._id);
        if (myAvailability) setFacultyAvail(myAvailability.status);
      }
    } else failures.push('faculty availability');

    if (warningsResult.status === 'fulfilled' && Array.isArray(warningsResult.value)) {
      nextStats.flaggedWarningCount = warningsResult.value.length;
      successfulLoads += 1;
    } else failures.push('early warnings');

    if (doubtsResult.status === 'fulfilled' && Array.isArray(doubtsResult.value)) {
      nextStats.openDoubtsCount = doubtsResult.value.length;
      successfulLoads += 1;
    } else failures.push('open doubts');

    setStats(current => ({ ...current, ...nextStats }));

    if (isAdmin) {
      const statuses = ['pending', 'approved', 'rejected'];
      const approvalResults = results.slice(4);
      const nextApprovalCounts = {};
      approvalResults.forEach((result, index) => {
        if (result.status === 'fulfilled' && Array.isArray(result.value)) {
          nextApprovalCounts[statuses[index]] = result.value.length;
          successfulLoads += 1;
        } else failures.push(`${statuses[index]} registrations`);
      });
      setApprovalCounts(current => ({ ...current, ...nextApprovalCounts }));
      if (approvalResults[0]?.status === 'fulfilled' && Array.isArray(approvalResults[0].value)) {
        setPendingRegistrations(approvalResults[0].value.slice(0, 4));
      }
    }

    setRefreshError(failures.length ? `Couldn't refresh ${failures.join(', ')}. Showing the latest available data.` : '');
    if (successfulLoads) setLastUpdated(Date.now());
    } catch (error) {
      console.error('Dashboard refresh failed:', error);
      setRefreshError('Dashboard data could not be refreshed. Please try again.');
    } finally {
      refreshInFlight.current = false;
      setIsRefreshing(false);
    }
  };

  const reviewRegistration = async (student, status) => {
    try {
      await apiFetch(`/users/${student._id}/approval`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      setPendingRegistrations(current => current.filter(entry => entry._id !== student._id));
      setApprovalCounts(current => ({ ...current, pending: Math.max(0, current.pending - 1), [status]: current[status] + 1 }));
    } catch (error) {
      alert(error.message);
    }
  };

  const handleToggleAvail = async (status) => {
    try {
      setFacultyAvail(status);
      await apiFetch('/availability/toggle', {
        method: 'POST',
        body: JSON.stringify({ status })
      });
    } catch (e) {
      console.error(e);
    }
  };

  const downloadHODReport = async () => {
    try {
      setDownloadingReport(true);
      const blob = await apiFetch('/reports/hod-pdf');
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `HOD_Monthly_Department_Report_${Date.now()}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      alert('Failed to generate PDF report: ' + e.message);
    } finally {
      setDownloadingReport(false);
    }
  };

  return (
    <div className="space-y-6">
      
      <header className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase text-slate-500">{user?.department?.name || 'KIT Campus'}</p>
          <h1 className="mt-1 text-2xl font-semibold text-slate-900">Welcome back, {user?.name}</h1>
          <p className="mt-1 text-sm text-slate-600">Here’s what needs your attention today.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {lastUpdated && <span className="text-xs text-slate-500">Updated {new Date(lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
          <button type="button" onClick={loadDashboardData} disabled={isRefreshing} title="Refresh dashboard" className="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60">
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />Refresh
          </button>
          {['admin', 'super_admin'].includes(user?.role) && (
            <button
              onClick={downloadHODReport}
              disabled={downloadingReport}
              className="inline-flex items-center gap-2 self-start rounded-md bg-slate-900 px-4 py-2.5 text-xs font-bold text-white hover:bg-slate-700 disabled:opacity-50 sm:self-auto"
            >
              <FileText className="h-4 w-4" />
              {downloadingReport ? 'Generating PDF...' : 'Download Monthly HOD PDF Report'}
            </button>
          )}
        </div>
      </header>

      {refreshError && <p role="alert" className="border-l-4 border-amber-500 bg-amber-50 px-4 py-3 text-sm text-amber-900">{refreshError}</p>}

      {['admin', 'super_admin'].includes(user?.role) && (
        <section className="space-y-4 border-b border-slate-200 pb-6" aria-labelledby="registration-dashboard-title">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 id="registration-dashboard-title" className="text-lg font-bold text-slate-900">Student registrations</h2>
              <p className="text-xs text-slate-500">Review roster-verified profiles before granting campus access.</p>
            </div>
            <Link to="/admin/registrations" className="inline-flex items-center gap-2 rounded-md bg-blue-700 px-3 py-2 text-xs font-bold text-white hover:bg-blue-800">
              <UserRoundCheck className="h-4 w-4" /> Review all registrations
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {['pending', 'approved', 'rejected'].map(status => (
              <Link key={status} to={`/admin/registrations?status=${status}`} className={`border-l-4 bg-white px-4 py-3 transition hover:bg-slate-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700 ${status === 'pending' ? 'border-amber-500' : status === 'approved' ? 'border-emerald-600' : 'border-rose-600'}`}>
                <p className="text-xs font-semibold capitalize text-slate-500">{status}</p>
                <p className="mt-1 text-2xl font-bold text-slate-900">{approvalCounts[status] ?? '—'}</p>
              </Link>
            ))}
          </div>
          {pendingRegistrations.length > 0 ? (
            <div className="divide-y divide-slate-200 border-y border-slate-200 bg-white">
              {pendingRegistrations.map(student => (
                <article key={student._id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-48">
                    <h3 className="text-sm font-bold text-slate-900">{student.name}</h3>
                    <p className="text-xs text-slate-500">{student.registerNumber} · {student.department?.code} · {student.className}</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-xs">
                    <a href={student.linkedin} target="_blank" rel="noreferrer" className="text-blue-700 underline">LinkedIn</a>
                    {student.portfolio && <a href={student.portfolio} target="_blank" rel="noreferrer" className="text-blue-700 underline">Portfolio</a>}
                    <button onClick={() => reviewRegistration(student, 'approved')} className="inline-flex items-center gap-1 rounded-md bg-emerald-700 px-3 py-2 font-bold text-white"><CheckCircle className="h-4 w-4" />Approve</button>
                    <button onClick={() => reviewRegistration(student, 'rejected')} className="inline-flex items-center gap-1 rounded-md border border-rose-300 px-3 py-2 font-bold text-rose-700"><X className="h-4 w-4" />Reject</button>
                  </div>
                </article>
              ))}
            </div>
          ) : <p className="border-y border-slate-200 bg-white px-4 py-5 text-sm text-slate-500">No registrations are waiting for review.</p>}
        </section>
      )}

      {user?.role === 'student' && (
        <section className="grid grid-cols-2 gap-2 sm:grid-cols-5" aria-label="KIT Hub modules">
          {[
            { to: '/announcements', label: 'Announcements', Icon: Megaphone },
            { to: '/chat', label: 'Messages', Icon: MessageCircle },
            { to: '/blood-finder', label: 'Blood Finder', Icon: HeartPulse },
            { to: '/directory', label: 'Staff Directory', Icon: Users },
            { to: '/profile', label: 'My Profile', Icon: UserRound }
          ].map(({ to, label, Icon }) => (
            <Link key={to} to={to} className="flex items-center gap-2 border border-slate-200 bg-white px-3 py-3 text-xs font-bold text-slate-700 hover:border-blue-500 hover:text-blue-800">
              <Icon className="h-4 w-4 shrink-0" />{label}
            </Link>
          ))}
        </section>
      )}

      {/* Quick Status Toggle for Faculty / HOD */}
      {['staff', 'admin'].includes(user?.role) && (
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600" />
            Quick Faculty Availability Status Toggle (Live to Students)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { status: 'Free', color: 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100' },
              { status: 'In cabin', color: 'bg-blue-50 text-blue-700 border-blue-300 hover:bg-blue-100' },
              { status: 'In class', color: 'bg-amber-50 text-amber-700 border-amber-300 hover:bg-amber-100' },
              { status: 'On leave', color: 'bg-rose-50 text-rose-700 border-rose-300 hover:bg-rose-100' }
            ].map(item => (
              <button
                key={item.status}
                onClick={() => handleToggleAvail(item.status)}
                className={`px-4 py-3 rounded-xl font-bold text-xs border transition flex items-center justify-between ${item.color} ${facultyAvail === item.status ? 'ring-2 ring-blue-600 font-extrabold shadow-sm' : ''}`}
              >
                <span>{item.status}</span>
                {facultyAvail === item.status && <CheckCircle className="w-4 h-4" />}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 border-y border-slate-200 sm:grid-cols-2 lg:grid-cols-4">

        <Link to="/tickets" className="flex items-center justify-between border-b border-slate-200 px-4 py-4 transition hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700 sm:border-r lg:border-b-0">
          <div>
            <p className="text-xs font-semibold text-slate-500">Pending tickets</p>
            <p className="mt-1 text-2xl font-semibold text-slate-900">{stats.pendingTickets ?? '—'}</p>
          </div>
          <div className="rounded-md bg-blue-50 p-3 text-blue-700">
            <Ticket className="w-6 h-6" />
          </div>
        </Link>

        <Link to="/availability" className="flex items-center justify-between border-b border-slate-200 px-4 py-4 transition hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700 lg:border-r lg:border-b-0">
          <div>
            <p className="text-xs font-semibold text-slate-500">Available faculty</p>
            <p className="mt-1 text-2xl font-semibold text-slate-900">{stats.freeFacultyCount ?? '—'}</p>
          </div>
          <div className="rounded-md bg-emerald-50 p-3 text-emerald-700">
            <Clock className="w-6 h-6" />
          </div>
        </Link>

        <Link to="/early-warning" className="flex items-center justify-between border-b border-slate-200 px-4 py-4 transition hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700 sm:border-r sm:border-b-0">
          <div>
            <p className="text-xs font-semibold text-slate-500">Early warnings</p>
            <p className="mt-1 text-2xl font-semibold text-rose-700">{stats.flaggedWarningCount ?? '—'}</p>
          </div>
          <div className="rounded-md bg-rose-50 p-3 text-rose-700">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </Link>

        <Link to="/doubts" className="flex items-center justify-between px-4 py-4 transition hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700">
          <div>
            <p className="text-xs font-semibold text-slate-500">Open doubts</p>
            <p className="mt-1 text-2xl font-semibold text-amber-700">{stats.openDoubtsCount ?? '—'}</p>
          </div>
          <div className="rounded-md bg-amber-50 p-3 text-amber-800">
            <HelpCircle className="w-6 h-6" />
          </div>
        </Link>

      </div>

      {/* Feature Navigation Grid */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          Quick Portal Features
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          
          <Link to="/tickets" className="p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition">
                <Ticket className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">Request Tickets</h3>
            <p className="text-xs text-slate-500 mt-1">Leave, OD, Bonafide & SLA auto-escalation timeline.</p>
          </Link>

          <Link to="/slots" className="p-4 rounded-xl border border-slate-200 hover:border-emerald-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg group-hover:bg-emerald-600 group-hover:text-white transition">
                <Calendar className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">Book 10-Min Slot</h3>
            <p className="text-xs text-slate-500 mt-1">Schedule 1-on-1 consultations with faculty.</p>
          </Link>

          <Link to="/doubts" className="p-4 rounded-xl border border-slate-200 hover:border-purple-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-purple-50 text-purple-600 rounded-lg group-hover:bg-purple-600 group-hover:text-white transition">
                <HelpCircle className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">Doubt Wall</h3>
            <p className="text-xs text-slate-500 mt-1">Post academic doubts openly or anonymously.</p>
          </Link>

          <Link to="/ai-assistant" className="p-4 rounded-xl border border-slate-200 hover:border-amber-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg group-hover:bg-amber-600 group-hover:text-white transition">
                <Bot className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">AI Assistant</h3>
            <p className="text-xs text-slate-500 mt-1">Claude-powered college FAQs & OD guidance.</p>
          </Link>

          <Link to="/early-warning" className="p-4 rounded-xl border border-slate-200 hover:border-rose-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-rose-50 text-rose-600 rounded-lg group-hover:bg-rose-600 group-hover:text-white transition">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-rose-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">Early Warning Dashboard</h3>
            <p className="text-xs text-slate-500 mt-1">Track low performers (&lt;75% att / &lt;50% marks).</p>
          </Link>

          <Link to="/directory" className="p-4 rounded-xl border border-slate-200 hover:border-cyan-400 hover:shadow-md transition group">
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-cyan-50 text-cyan-600 rounded-lg group-hover:bg-cyan-600 group-hover:text-white transition">
                <Users className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-cyan-600 transition" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mt-3">Directory</h3>
            <p className="text-xs text-slate-500 mt-1">Contact details & status of faculty & staff.</p>
          </Link>

        </div>
      </div>

    </div>
  );
};
