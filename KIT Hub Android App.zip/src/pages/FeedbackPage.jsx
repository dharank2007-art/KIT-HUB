import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { MessageSquareOff, Star, Sparkles, AlertTriangle, ShieldCheck, Send } from 'lucide-react';

export const FeedbackPage = () => {
  const { user } = useAuth();
  const [facultyList, setFacultyList] = useState([]);
  const [feedbacks, setFeedbacks] = useState([]);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);

  // Form states
  const [targetUserId, setTargetUserId] = useState('');
  const [category, setCategory] = useState('Teaching');
  const [content, setContent] = useState('');
  const [rating, setRating] = useState(5);
  const [submittedMessage, setSubmittedMessage] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const users = await apiFetch('/users?role=staff');
      setFacultyList(users);

      if (['admin', 'super_admin'].includes(user?.role)) {
        const list = await apiFetch('/feedback');
        setFeedbacks(list);
        const sumRes = await apiFetch('/feedback/summary');
        setSummary(sumRes.summary);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await apiFetch('/feedback', {
        method: 'POST',
        body: JSON.stringify({
          targetUserId: targetUserId || null,
          category,
          content,
          rating
        })
      });

      setSubmittedMessage(res.message || 'Anonymous feedback submitted successfully!');
      setContent('');
      setTimeout(() => setSubmittedMessage(''), 4000);
      loadData();
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const sentimentBadges = {
    'Positive': 'bg-emerald-100 text-emerald-800 border-emerald-300',
    'Neutral': 'bg-slate-100 text-slate-800 border-slate-300',
    'Stressed/Negative': 'bg-rose-100 text-rose-800 border-rose-300 font-bold animate-pulse'
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <MessageSquareOff className="w-6 h-6 text-rose-600" />
            100% Anonymous Faculty & Department Feedback
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Zero user tracking! NO student ID is recorded. Integrated sentiment analysis flags stressed messages.
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-bold border border-emerald-200">
          <ShieldCheck className="w-4 h-4 text-emerald-600" /> Guaranteed Anonymous
        </div>
      </div>

      {/* AI Theme Summary Card for HOD / Super Admin */}
      {['admin', 'super_admin'].includes(user?.role) && (
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider">
              AI-Summarized Feedback Themes (Claude Analytics)
            </h2>
          </div>
          <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-line bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
            {summary || 'Analyzing student feedback batch with AI...'}
          </div>
        </div>
      )}

      {/* Anonymous Submission Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-4">
        <h2 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          Submit Confidential Anonymous Feedback
        </h2>

        {submittedMessage && (
          <div className="p-3 bg-emerald-50 text-emerald-700 text-xs rounded-xl font-semibold border border-emerald-200">
            ✓ {submittedMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Target Faculty / Department (Optional)</label>
            <select
              value={targetUserId}
              onChange={(e) => setTargetUserId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800"
            >
              <option value="">General Department Feedback</option>
              {facultyList.map(f => (
                <option key={f._id} value={f._id}>{f.name} ({f.department?.code || 'Faculty'})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800"
              >
                <option value="Teaching">Teaching Quality</option>
                <option value="Infrastructure">Infrastructure & Labs</option>
                <option value="Behaviour">Behaviour & Fairness</option>
                <option value="General">General Feedback</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Rating (1 to 5 Stars)</label>
              <select
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800"
              >
                <option value={5}>⭐⭐⭐⭐⭐ (5 - Excellent)</option>
                <option value={4}>⭐⭐⭐⭐ (4 - Good)</option>
                <option value={3}>⭐⭐⭐ (3 - Average)</option>
                <option value={2}>⭐⭐ (2 - Needs Improvement)</option>
                <option value={1}>⭐ (1 - Poor)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Feedback Comments</label>
            <textarea
              required
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Share honest feedback... Remember, no identification data is stored."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            {loading ? 'Submitting...' : 'Submit Anonymous Feedback'}
          </button>
        </form>
      </div>

      {/* Admin / HOD View of Feedback Feed */}
      {['admin', 'super_admin'].includes(user?.role) && (
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900">
            Submitted Department Feedback Batch ({feedbacks.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {feedbacks.map(fb => (
              <div key={fb._id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    Category: {fb.category}
                  </span>
                  <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full border ${sentimentBadges[fb.sentiment]}`}>
                    Sentiment: {fb.sentiment}
                  </span>
                </div>

                <div className="text-amber-500 text-xs font-bold">
                  {'★'.repeat(fb.rating || 5)}{'☆'.repeat(5 - (fb.rating || 5))}
                </div>

                <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                  "{fb.content}"
                </p>

                <div className="flex justify-between items-center text-[10px] text-slate-400">
                  <span>Target: {fb.targetUser?.name || 'Department'}</span>
                  <span>{new Date(fb.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
