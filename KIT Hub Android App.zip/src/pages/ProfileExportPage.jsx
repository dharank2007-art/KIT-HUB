import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { Download, Save } from 'lucide-react';

const validLinkedIn = value => /^https:\/\/(www\.)?linkedin\.com\/in\/[\w%-]+\/?$/i.test(value);

export const ProfileExportPage = () => {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState({ name: '', phone: '', className: '', bloodGroup: '', linkedin: '', portfolio: '' });
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiFetch('/auth/me').then(data => setProfile({
      name: data.name || '', phone: data.phone || '', className: data.className || '',
      bloodGroup: data.bloodGroup || '', linkedin: data.linkedin || '', portfolio: data.portfolio || ''
    })).catch(error => setMessage(error.message));
  }, []);

  const update = event => setProfile(current => ({ ...current, [event.target.name]: event.target.value }));
  const saveProfile = async event => {
    event.preventDefault();
    if (user?.role === 'student' && !validLinkedIn(profile.linkedin)) {
      setMessage('A valid LinkedIn profile URL is required.');
      return;
    }
    setSaving(true);
    setMessage('');
    try {
      const updated = await apiFetch(`/users/${user._id}`, { method: 'PUT', body: JSON.stringify(profile) });
      updateUser(updated);
      setMessage('Profile updated.');
    } catch (error) {
      setMessage(error.message);
    } finally {
      setSaving(false);
    }
  };

  const exportData = async format => {
    try {
      const result = await apiFetch(`/users/me/export?format=${format}`);
      const type = format === 'pdf' ? 'application/pdf' : format === 'csv' ? 'text/csv' : 'application/json';
      const blob = result instanceof Blob ? result : new Blob([format === 'json' ? JSON.stringify(result, null, 2) : result], { type });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `kit-hub-my-data.${format}`;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header className="border-b border-slate-200 pb-4"><h1 className="text-xl font-bold text-slate-900">My Profile</h1><p className="mt-1 text-sm text-slate-500">Review your account details and download your personal data.</p></header>
      <section className="grid gap-6 md:grid-cols-[1fr_auto]">
        <form onSubmit={saveProfile} className="grid gap-4 sm:grid-cols-2">
          <label className="text-xs font-semibold text-slate-600">Name<input name="name" required value={profile.name} onChange={update} className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900" /></label>
          <label className="text-xs font-semibold text-slate-600">Email<input readOnly value={user?.email || ''} className="mt-1 w-full rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-600" /></label>
          {user?.role === 'student' && <>
            <label className="text-xs font-semibold text-slate-600">Roll number<input readOnly value={user?.registerNumber || ''} className="mt-1 w-full rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-600" /></label>
            <label className="text-xs font-semibold text-slate-600">Department / Class<input readOnly value={`${user?.department?.code || ''} / ${profile.className}`} className="mt-1 w-full rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-600" /></label>
            <label className="text-xs font-semibold text-slate-600">Blood group<select name="bloodGroup" value={profile.bloodGroup} onChange={update} className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"><option value="">Select</option>{['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(group => <option key={group}>{group}</option>)}</select></label>
            <label className="text-xs font-semibold text-slate-600 sm:col-span-2">LinkedIn profile<input name="linkedin" type="url" required value={profile.linkedin} onChange={update} placeholder="https://www.linkedin.com/in/your-profile" className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900" /></label>
            <label className="text-xs font-semibold text-slate-600 sm:col-span-2">Portfolio URL (optional)<input name="portfolio" type="url" value={profile.portfolio} onChange={update} className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900" /></label>
          </>}
          <label className="text-xs font-semibold text-slate-600">Phone<input name="phone" value={profile.phone} onChange={update} className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900" /></label>
          <div className="flex items-end"><button disabled={saving} className="inline-flex items-center gap-2 rounded-md bg-blue-700 px-4 py-2.5 text-sm font-bold text-white disabled:opacity-50"><Save className="h-4 w-4" />{saving ? 'Saving...' : 'Save profile'}</button></div>
        </form>
        <aside className="border-t border-slate-200 pt-5 md:border-l md:border-t-0 md:pl-6 md:pt-0">
          <h2 className="font-bold text-slate-900">Export my data</h2>
          <p className="mb-3 mt-1 text-xs text-slate-500">Download only your own profile information.</p>
          <div className="flex gap-2 md:flex-col">{['pdf', 'json', 'csv'].map(format => <button key={format} onClick={() => exportData(format)} className="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold uppercase text-slate-700 hover:bg-slate-50"><Download className="h-4 w-4" />{format}</button>)}</div>
        </aside>
      </section>
      {message && <p className="text-sm text-slate-600" role="status">{message}</p>}
    </div>
  );
};