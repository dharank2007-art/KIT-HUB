import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { Clock, MapPin, CheckCircle, FileText } from 'lucide-react';

export const AvailabilityPage = () => {
  const { user } = useAuth();
  const [availabilities, setAvailabilities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [note, setNote] = useState('');
  const [location, setLocation] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('Free');

  useEffect(() => {
    loadAvailabilities();
  }, []);

  const loadAvailabilities = async () => {
    try {
      setLoading(true);
      const data = await apiFetch('/availability');
      setAvailabilities(data);

      const myAvail = data.find(a => a.faculty?._id === user?._id || a.faculty === user?._id);
      if (myAvail) {
        setSelectedStatus(myAvail.status);
        setNote(myAvail.note || '');
        setLocation(myAvail.location || '');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (statusOverride) => {
    try {
      const st = statusOverride || selectedStatus;
      await apiFetch('/availability/toggle', {
        method: 'POST',
        body: JSON.stringify({
          status: st,
          note,
          location
        })
      });
      setSelectedStatus(st);
      loadAvailabilities();
    } catch (err) {
      alert(err.message);
    }
  };

  const statusColors = {
    'Free': 'bg-emerald-100 text-emerald-800 border-emerald-300',
    'In cabin': 'bg-blue-100 text-blue-800 border-blue-300',
    'In class': 'bg-amber-100 text-amber-800 border-amber-300',
    'On leave': 'bg-rose-100 text-rose-800 border-rose-300'
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-6 h-6 text-emerald-600" />
            Faculty Live Cabin & Class Availability
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time status indicators (In class / In cabin / Free / On leave) for students and department heads.
          </p>
        </div>
      </div>

      {/* Quick Update Card for Faculty / HOD */}
      {['staff', 'admin'].includes(user?.role) && (
        <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
            Update My Live Status
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {['Free', 'In cabin', 'In class', 'On leave'].map(st => (
              <button
                key={st}
                onClick={() => {
                  setSelectedStatus(st);
                  handleUpdate(st);
                }}
                className={`py-3 px-4 rounded-xl font-bold text-xs border transition flex items-center justify-center gap-2 ${
                  selectedStatus === st 
                    ? 'bg-blue-600 text-white border-blue-500 shadow-lg' 
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                <span>{st}</span>
                {selectedStatus === st && <CheckCircle className="w-4 h-4" />}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs text-slate-300 mb-1 font-semibold">Location / Cabin No.</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Block A Cabin 204"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-300 mb-1 font-semibold">Status Note / Return Time</label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. Back from class at 3:30 PM"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => handleUpdate()}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow"
            >
              Save Custom Note & Location
            </button>
          </div>
        </div>
      )}

      {/* Live Faculty Grid */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading faculty statuses...</div>
      ) : availabilities.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No faculty availability entries recorded yet.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availabilities.map(a => (
            <div key={a._id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-1 font-bold text-xs rounded-full border ${statusColors[a.status] || 'bg-slate-100'}`}>
                  ● {a.status}
                </span>
                <span className="text-[10px] text-slate-400">
                  Updated {new Date(a.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 text-base">{a.faculty?.name || 'Faculty Member'}</h3>
                <p className="text-xs text-slate-500 font-medium">
                  {a.faculty?.department?.name || 'KIT Faculty'} ({a.faculty?.role === 'admin' ? 'HOD' : 'Faculty'})
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs space-y-1">
                {a.location && (
                  <p className="flex items-center gap-1.5 text-slate-700 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    <span>{a.location}</span>
                  </p>
                )}
                {a.note ? (
                  <p className="flex items-center gap-1.5 text-slate-600">
                    <FileText className="w-3.5 h-3.5 text-amber-500" />
                    <span>"{a.note}"</span>
                  </p>
                ) : (
                  <p className="text-slate-400 italic">No notes provided</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
