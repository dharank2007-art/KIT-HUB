import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { HelpCircle, ThumbsUp, CheckCircle, MessageSquare, Plus, Search, EyeOff, Tag } from 'lucide-react';

export const DoubtWallPage = () => {
  const { user } = useAuth();
  const [doubts, setDoubts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [activeDoubt, setActiveDoubt] = useState(null);

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [tags, setTags] = useState('');
  const [answerContent, setAnswerContent] = useState('');

  useEffect(() => {
    loadDoubts();
  }, [search]);

  const loadDoubts = async () => {
    try {
      setLoading(true);
      const url = search ? `/doubts?search=${encodeURIComponent(search)}` : '/doubts';
      const data = await apiFetch(url);
      setDoubts(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePostDoubt = async (e) => {
    e.preventDefault();
    try {
      const tagArray = tags.split(',').map(t => t.trim()).filter(Boolean);
      await apiFetch('/doubts', {
        method: 'POST',
        body: JSON.stringify({
          title,
          content,
          isAnonymous,
          tags: tagArray
        })
      });
      setTitle('');
      setContent('');
      setIsAnonymous(false);
      setTags('');
      setShowModal(false);
      loadDoubts();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleUpvote = async (doubtId, e) => {
    e.stopPropagation();
    try {
      await apiFetch(`/doubts/${doubtId}/upvote`, { method: 'POST' });
      loadDoubts();
    } catch (err) {
      alert(err.message);
    }
  };

  const handlePostAnswer = async (doubtId) => {
    if (!answerContent.trim()) return;
    try {
      await apiFetch(`/doubts/${doubtId}/answers`, {
        method: 'POST',
        body: JSON.stringify({ content: answerContent })
      });
      setAnswerContent('');
      loadDoubts();
      const updated = await apiFetch('/doubts');
      setActiveDoubt(updated.find(d => d._id === doubtId));
    } catch (err) {
      alert(err.message);
    }
  };

  const handleToggleResolve = async (doubtId) => {
    try {
      await apiFetch(`/doubts/${doubtId}/resolve`, { method: 'PUT' });
      loadDoubts();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-purple-600" />
            Academic Doubt Wall (Open & Anonymous)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Ask questions freely to peer students and faculty, upvote useful solutions, and mark doubts as resolved.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          Ask a Doubt
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search doubts by title, keywords or tags..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
      </div>

      {/* Doubts Grid */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm">Loading Doubt Wall...</div>
      ) : doubts.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center text-slate-500 border border-slate-200">
          No doubts found matching your search.
        </div>
      ) : (
        <div className="space-y-4">
          {doubts.map(d => (
            <div 
              key={d._id}
              onClick={() => setActiveDoubt(d)}
              className={`bg-white p-5 rounded-2xl border shadow-sm hover:shadow-md transition cursor-pointer space-y-3 ${
                d.isResolved ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-800">
                    {d.isAnonymous ? '👤 Anonymous Student' : d.author?.name}
                  </span>
                  {d.department && (
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-semibold">
                      {d.department?.code}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {d.isResolved && (
                    <span className="flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-100 font-bold px-2 py-0.5 rounded-full">
                      <CheckCircle className="w-3 h-3" /> Resolved
                    </span>
                  )}
                  <span className="text-[11px] text-slate-400">
                    {new Date(d.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 text-base">{d.title}</h3>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">{d.content}</p>
              </div>

              {d.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {d.tags.map((tg, idx) => (
                    <span key={idx} className="text-[10px] font-semibold bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">
                      #{tg}
                    </span>
                  ))}
                </div>
              )}

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-4">
                  <button
                    onClick={(e) => handleUpvote(d._id, e)}
                    className="flex items-center gap-1 hover:text-purple-600 font-semibold"
                  >
                    <ThumbsUp className="w-4 h-4 text-purple-600" />
                    <span>{d.upvotes?.length || 0} Upvotes</span>
                  </button>

                  <span className="flex items-center gap-1 font-semibold">
                    <MessageSquare className="w-4 h-4 text-slate-400" />
                    <span>{d.answers?.length || 0} Answers</span>
                  </span>
                </div>

                <span className="text-xs text-purple-600 font-bold hover:underline">
                  View Discussion →
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Doubt Detail & Discussion Modal */}
      {activeDoubt && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 text-slate-800 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-xs text-slate-500 font-semibold">
                  {activeDoubt.isAnonymous ? 'Anonymous Post' : `By ${activeDoubt.author?.name}`}
                </span>
                <h2 className="text-lg font-bold text-slate-900">{activeDoubt.title}</h2>
              </div>
              <button onClick={() => setActiveDoubt(null)} className="text-slate-400 font-bold text-lg">✕</button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl text-xs leading-relaxed text-slate-800 border border-slate-200">
              {activeDoubt.content}
            </div>

            {/* Answers List */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Answers & Solutions ({activeDoubt.answers?.length || 0})
              </h3>

              <div className="space-y-3">
                {activeDoubt.answers?.map((ans, i) => (
                  <div key={i} className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${ans.isFaculty ? 'bg-amber-50/60 border-amber-200' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 flex items-center gap-1.5">
                        {ans.author?.name}
                        {ans.isFaculty && (
                          <span className="px-1.5 py-0.2 bg-amber-400 text-slate-950 rounded text-[10px] font-black uppercase">
                            Faculty Verified
                          </span>
                        )}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(ans.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-slate-800">{ans.content}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Submit Answer Form */}
            <div className="pt-2 border-t border-slate-200 space-y-2">
              <textarea
                rows={3}
                value={answerContent}
                onChange={(e) => setAnswerContent(e.target.value)}
                placeholder="Write your answer or explanation..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
              />
              <div className="flex justify-between items-center">
                <button
                  onClick={() => handleToggleResolve(activeDoubt._id)}
                  className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 text-xs font-bold rounded-lg border border-emerald-300"
                >
                  {activeDoubt.isResolved ? 'Mark Unresolved' : '✓ Mark Resolved'}
                </button>
                <button
                  onClick={() => handlePostAnswer(activeDoubt._id)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow"
                >
                  Post Answer
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Ask Doubt Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">Post a Doubt</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handlePostDoubt} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Title / Question</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. How to solve Dijkstra algorithm time complexity?"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Details & Context</label>
                <textarea
                  required
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Explain your doubt in detail..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tags (Comma Separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="algorithms, python, cse"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="anonCheck"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
                />
                <label htmlFor="anonCheck" className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                  <EyeOff className="w-3.5 h-3.5 text-slate-500" /> Post Anonymously
                </label>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  Post Doubt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
