import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../services/api';
import { Shield, Lock, Mail, ArrowRight } from 'lucide-react';

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const data = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });

      login(data, data.token);

      if (!data.isPasswordChanged) {
        navigate('/change-password');
      } else {
        navigate('/');
      }
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (demoEmail, demoPass) => {
    setEmail(demoEmail);
    setPassword(demoPass);
  };

  return (
    <main className="min-h-screen bg-[#f3f6f2] text-[#20342d] lg:grid lg:grid-cols-2">
      <section className="flex min-h-[280px] flex-col justify-between bg-[#244b3e] px-6 py-7 text-white sm:px-10 lg:min-h-screen lg:px-16 lg:py-12">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/30">
            <Shield className="h-5 w-5 text-[#e9b75a]" />
          </span>
          <div>
            <p className="text-sm font-bold">KIT College</p>
            <p className="text-xs text-white/70">Campus portal</p>
          </div>
        </div>
        <div className="my-10 max-w-lg lg:my-auto">
          <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[#e9b75a]">Welcome back</p>
          <h1 className="mt-4 font-serif text-4xl leading-tight sm:text-5xl">Good to see you.</h1>
          <p className="mt-4 max-w-md text-sm leading-6 text-white/75">Sign in with your college account to continue.</p>
        </div>
        <p className="text-xs text-white/55">Students · Faculty · Administration</p>
      </section>

      <section className="flex items-center justify-center px-5 py-10 sm:px-10 lg:px-16">
        <div className="w-full max-w-md">
          <h2 className="font-serif text-3xl font-medium text-[#20342d]">Sign in</h2>
          <p className="mt-2 text-sm text-[#66746e]">Use the email address registered with KIT.</p>

          {error && <div role="alert" className="mt-6 border-l-4 border-[#b94b3b] bg-white px-4 py-3 text-sm text-[#8e392e]">{error}</div>}

          <form className="mt-7 space-y-5" onSubmit={handleSubmit}>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-[#33483f]">College email</label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#718079]" />
                <input type="email" autoComplete="username" required value={email} onChange={event => setEmail(event.target.value)} placeholder="name@kit.edu" className="w-full rounded-md border border-[#cbd5cf] bg-white py-3 pl-10 pr-3 text-sm text-[#20342d] placeholder:text-[#8b9891] focus:border-[#356b55] focus:outline-none focus:ring-2 focus:ring-[#356b55]/20" />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-semibold text-[#33483f]">Password</label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#718079]" />
                <input type="password" autoComplete="current-password" required value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter your password" className="w-full rounded-md border border-[#cbd5cf] bg-white py-3 pl-10 pr-3 text-sm text-[#20342d] placeholder:text-[#8b9891] focus:border-[#356b55] focus:outline-none focus:ring-2 focus:ring-[#356b55]/20" />
              </div>
            </div>

            <button type="submit" disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-md bg-[#285c47] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#1e4938] focus:outline-none focus:ring-2 focus:ring-[#285c47] focus:ring-offset-2 disabled:opacity-60">
              {loading ? 'Signing in...' : 'Continue'}<ArrowRight className="h-4 w-4" />
            </button>
          </form>

          <p className="mt-6 border-t border-[#d8e0da] pt-5 text-sm text-[#66746e]">
            New student? <Link to="/register" className="font-semibold text-[#285c47] underline decoration-[#a8c0b0] underline-offset-4 hover:text-[#1e4938]">Request an account</Link>
          </p>

          {import.meta.env.DEV && (
            <details className="mt-6 border-t border-[#d8e0da] pt-4 text-xs text-[#66746e]">
              <summary className="cursor-pointer font-semibold">Development accounts</summary>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {[
                  ['Super Admin', 'superadmin@kit.edu', 'Admin@123'],
                  ['HOD', 'hod.cse@kit.edu', 'Faculty@123'],
                  ['Faculty', 'faculty.anita@kit.edu', 'Faculty@123'],
                  ['Student', 'student1@kit.edu', 'Student@123']
                ].map(([label, demoEmail, demoPassword]) => (
                  <button key={label} type="button" onClick={() => { setEmail(demoEmail); setPassword(demoPassword); }} className="rounded border border-[#d8e0da] px-3 py-2 text-left font-medium hover:bg-white">{label}</button>
                ))}
              </div>
            </details>
          )}
        </div>
      </section>
    </main>
  );
};
