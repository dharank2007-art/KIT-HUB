import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch, backendUrl } from '../services/api';
import { 
  Ticket as TicketIcon, 
  Plus, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Paperclip, 
  Zap, 
  User, 
  Send
} from 'lucide-react';

export const TicketsPage = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('All');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('Leave');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [updateComment, setUpdateComment] = useState('');

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    try {
      setLoading(true);
      const data = await apiFetch('/tickets');
      setTickets(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTicket = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      await apiFetch('/tickets', {
        method: 'POST',
        body: JSON.stringify({
          title,
          description,
          type,
          attachments: attachmentUrl ? [attachmentUrl] : []
        })
      });
      setTitle('');
      setDescription('');
      setAttachmentUrl('');
      setShowCreateModal(false);
      loadTickets();
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateStatus = async (ticketId, status) => {
    try {
      await apiFetch(`/tickets/${ticketId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, comment: updateComment })
      });
      setUpdateComment('');
      loadTickets();
      if (selectedTicket?._id === ticketId) {
        const updated = await apiFetch(`/tickets`);
        setSelectedTicket(updated.find(t => t._id === ticketId));
      }
    } catch (err) {
      alert(err.message);
    }
  };

  const triggerEscalationCheck = async () => {
    try {
      const res = await apiFetch('/tickets/run-escalation', { method: 'POST' });
      alert(res.message);
      loadTickets();
    } catch (err) {
      alert(err.message);
    }
  };

  const filteredTickets = filterStatus === 'All' 
    ? tickets 
    : tickets.filter(t => t.status === filterStatus);

  const statusBadges = {
    Pending: 'bg-amber-100 text-amber-800 border-amber-300',
    Approved: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    Rejected: 'bg-rose-100 text-rose-800 border-rose-300',
    Escalated: 'bg-purple-100 text-purple-800 border-purple-300'
  };

  const escalationLabels = {
    0: 'Level 0 (Faculty Review)',
    1: 'Level 1 (HOD Escalated)',
    2: 'Level 2 (Super Admin Final Escalation)'
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <TicketIcon className="w-6 h-6 text-blue-600" />
            Request Tickets (Leave / OD / Bonafide / Doubt / Complaint)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track workflow approvals, attachments, and automatic 48-hour SLA escalation timeline.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {user?.role === 'super_admin' && (
            <button
              onClick={triggerEscalationCheck}
              className="flex items-center gap-1.5 px-3 py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 font-bold text-xs rounded-xl border border-purple-300 transition"
              title="Test 48h SLA Escalation Engine"
            >
              <Zap className="w-4 h-4 text-purple-600" />
              Test SLA Escalation
            </button>
          )}

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            <Plus className="w-4 h-4" />
            New Ticket
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-2">
        {['All', 'Pending', 'Approved', 'Rejected', 'Escalated'].map(st => (
          <button
            key={st}
            onClick={() => setFilterStatus(st)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filterStatus === st 
                ? 'bg-slate-900 text-white shadow' 
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {st} {st === 'All' ? `(${tickets.length})` : `(${tickets.filter(t => t.status === st).length})`}
          </button>
        ))}
      </div>

      {/* Tickets List Grid */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 text-sm font-medium">Loading request tickets...</div>
      ) : filteredTickets.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl text-center border border-slate-200 text-slate-500 text-sm">
          No request tickets found under status "{filterStatus}".
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredTickets.map(t => (
            <div 
              key={t._id} 
              onClick={() => setSelectedTicket(t)}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-slate-100 text-slate-700 font-bold text-[11px] rounded-lg border border-slate-200">
                    {t.type}
                  </span>
                  <span className={`px-2.5 py-0.5 font-bold text-[11px] rounded-full border ${statusBadges[t.status]}`}>
                    {t.status}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400">
                  {new Date(t.createdAt).toLocaleDateString()}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 text-sm line-clamp-1">{t.title}</h3>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">{t.description}</p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-semibold text-slate-700">{t.student?.name}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-purple-700 font-bold bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                  <Clock className="w-3 h-3" />
                  {escalationLabels[t.escalationLevel] || `Level ${t.escalationLevel}`}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Ticket Details & Timeline Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5 text-slate-800">
            
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="px-2.5 py-1 bg-slate-100 text-slate-700 font-bold text-[11px] rounded-lg border border-slate-200">
                  {selectedTicket.type} Ticket
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">{selectedTicket.title}</h2>
              </div>
              <button 
                onClick={() => setSelectedTicket(null)} 
                className="p-1 text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <p className="font-semibold text-slate-700">Description:</p>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 leading-relaxed">
                {selectedTicket.description}
              </div>
            </div>

            {selectedTicket.attachments?.length > 0 && (
              <div className="space-y-1">
                <p className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                  <Paperclip className="w-3.5 h-3.5 text-blue-600" /> Attachments:
                </p>
                {selectedTicket.attachments.map((att, i) => (
                  <a 
                    key={i} 
                    href={backendUrl(att)} 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-xs text-blue-600 underline font-medium block"
                  >
                    Attachment #{i + 1} ({att})
                  </a>
                ))}
              </div>
            )}

            {/* Timeline Log */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Audit Timeline & Status Log
              </h3>
              <div className="space-y-2 border-l-2 border-slate-200 pl-4">
                {selectedTicket.timeline?.map((step, idx) => (
                  <div key={idx} className="relative text-xs space-y-0.5">
                    <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-white" />
                    <div className="flex items-center gap-2">
                      <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${statusBadges[step.status]}`}>
                        {step.status}
                      </span>
                      <span className="text-slate-400 text-[10px]">
                        {new Date(step.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-700 font-medium">{step.comment}</p>
                    {step.updatedBy && (
                      <p className="text-[10px] text-slate-400">By: {step.updatedBy.name || step.updatedBy}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Actions for Faculty/HOD/Super Admin */}
            {['staff', 'admin', 'super_admin'].includes(user?.role) && selectedTicket.status !== 'Approved' && (
              <div className="pt-4 border-t border-slate-200 space-y-3">
                <input
                  type="text"
                  placeholder="Optional review remark or comment..."
                  value={updateComment}
                  onChange={(e) => setUpdateComment(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => handleUpdateStatus(selectedTicket._id, 'Approved')}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition"
                  >
                    Approve Ticket
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedTicket._id, 'Rejected')}
                    className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow transition"
                  >
                    Reject Ticket
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedTicket._id, 'Escalated')}
                    className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow transition"
                  >
                    Escalate Level
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* Create Ticket Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 text-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900">Create Request Ticket</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ticket Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                >
                  <option value="Leave">Leave Request</option>
                  <option value="OD">On Duty (OD) Request</option>
                  <option value="Bonafide">Bonafide Certificate</option>
                  <option value="Doubt">Academic Doubt</option>
                  <option value="Complaint">Grievance / Complaint</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Title / Subject</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Leave for TechFest Hackathon participation"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Details & Reason</label>
                <textarea
                  required
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide complete explanation..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Attachment URL (Optional)</label>
                <input
                  type="text"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  placeholder="http://... or /uploads/file.pdf"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow"
                >
                  {submitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
