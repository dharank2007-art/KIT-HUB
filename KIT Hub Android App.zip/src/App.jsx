import React, { useState } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { QRCheckinModal } from './components/QRCheckinModal';

import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { FirstLoginPasswordChange } from './pages/FirstLoginPasswordChange';
import { Dashboard } from './pages/Dashboard';
import { TicketsPage } from './pages/TicketsPage';
import { AvailabilityPage } from './pages/AvailabilityPage';
import { SlotBookingPage } from './pages/SlotBookingPage';
import { DoubtWallPage } from './pages/DoubtWallPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { MentorDiaryPage } from './pages/MentorDiaryPage';
import { AIAssistantPage } from './pages/AIAssistantPage';
import { EarlyWarningPage } from './pages/EarlyWarningPage';
import { AchievementWallPage } from './pages/AchievementWallPage';
import { AnnouncementsPage } from './pages/AnnouncementsPage';
import { ChatPage } from './pages/ChatPage';
import { DirectoryPage } from './pages/DirectoryPage';
import { BulkUserUploadPage } from './pages/BulkUserUploadPage';
import { AdminApprovalsPage } from './pages/AdminApprovalsPage';
import { BloodFinderPage } from './pages/BloodFinderPage';
import { ProfileExportPage } from './pages/ProfileExportPage';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, token, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-slate-500 font-bold text-sm">Loading app...</div>;
  }

  if (!token || !user) {
    return <Navigate to="/login" replace />;
  }

  // Force first-time password change
  if (!user.isPasswordChanged && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export function App() {
  const { user } = useAuth();
  const [showQR, setShowQR] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 font-sans flex flex-col">
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        <Route
          path="/*"
          element={
            <ProtectedRoute>
              <div className="flex flex-col min-h-screen">
                <Navbar onOpenQR={() => setShowQR(true)} />
                <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
                  <Sidebar />
                  <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-x-hidden">
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/change-password" element={<FirstLoginPasswordChange />} />
                      <Route path="/tickets" element={<TicketsPage />} />
                      <Route path="/availability" element={<AvailabilityPage />} />
                      <Route path="/slots" element={<SlotBookingPage />} />
                      <Route path="/doubts" element={<DoubtWallPage />} />
                      <Route path="/feedback" element={<FeedbackPage />} />
                      <Route path="/mentor-diary" element={<MentorDiaryPage />} />
                      <Route path="/ai-assistant" element={<AIAssistantPage />} />
                      <Route path="/early-warning" element={<EarlyWarningPage />} />
                      <Route path="/achievements" element={<AchievementWallPage />} />
                      <Route path="/announcements" element={<AnnouncementsPage />} />
                      <Route path="/chat" element={<ChatPage />} />
                      <Route path="/directory" element={<DirectoryPage />} />
                      <Route path="/blood-finder" element={<BloodFinderPage />} />
                      <Route path="/profile" element={<ProfileExportPage />} />
                      <Route path="/admin/registrations" element={<ProtectedRoute allowedRoles={['admin', 'super_admin']}><AdminApprovalsPage /></ProtectedRoute>} />
                      
                      <Route 
                        path="/bulk-upload" 
                        element={
                          <ProtectedRoute allowedRoles={['super_admin']}>
                            <BulkUserUploadPage />
                          </ProtectedRoute>
                        } 
                      />

                      <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
                  </main>
                </div>

                {showQR && <QRCheckinModal onClose={() => setShowQR(false)} />}
              </div>
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
