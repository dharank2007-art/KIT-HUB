const test = require('node:test');
const assert = require('node:assert/strict');
const User = require('../server/models/User');
const Feedback = require('../server/models/Feedback');
const BloodRequest = require('../server/models/BloodRequest');
const { requireRole } = require('../server/middleware/roleMiddleware');

test('user schema preserves existing role names and department association', () => {
  assert.deepEqual(User.schema.path('role').enumValues, ['super_admin', 'admin', 'staff', 'student']);
  assert.ok(User.schema.path('department'));
  const user = new User({ name: 'Test Student', email: 'test@example.edu', password: 'temporary', role: 'student' });
  assert.equal(user.isPasswordChanged, false);
});

test('feedback schema stores no submitting user identifier', () => {
  assert.equal(Feedback.schema.path('userId'), undefined);
  assert.equal(Feedback.schema.path('studentId'), undefined);
});

test('blood requests require an urgency, donor, requester, and location', () => {
  const request = new BloodRequest({ bloodGroup: 'O+', urgency: 'critical' });
  const validationError = request.validateSync();
  assert.ok(validationError.errors.requester);
  assert.ok(validationError.errors.donor);
  assert.ok(validationError.errors.location);
  assert.deepEqual(BloodRequest.schema.path('urgency').enumValues, ['normal', 'urgent', 'critical']);
  assert.equal(request.status, 'pending');
});

test('role middleware blocks roles outside the allowlist', () => {
  let statusCode;
  let responseBody;
  const response = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(body) {
      responseBody = body;
      return this;
    }
  };
  const next = () => assert.fail('next must not run for an unauthorized role');

  requireRole('super_admin')({ user: { role: 'student' } }, response, next);
  assert.equal(statusCode, 403);
  assert.match(responseBody.message, /Access denied/);
});