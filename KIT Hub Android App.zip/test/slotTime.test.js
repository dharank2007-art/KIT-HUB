const test = require('node:test');
const assert = require('node:assert/strict');
const { timeToMinutes, isTenMinuteRange } = require('../server/utils/slotTime');

test('parses 12-hour and 24-hour time formats', () => {
  assert.equal(timeToMinutes('12:00 AM'), 0);
  assert.equal(timeToMinutes('10:00 AM'), 600);
  assert.equal(timeToMinutes('12:00 PM'), 720);
  assert.equal(timeToMinutes('23:50'), 1430);
});

test('rejects malformed and out-of-range times', () => {
  assert.equal(timeToMinutes('13:00 PM'), null);
  assert.equal(timeToMinutes('24:00'), null);
  assert.equal(timeToMinutes('10:75 AM'), null);
  assert.equal(timeToMinutes(null), null);
});

test('accepts only a valid ten-minute range', () => {
  assert.equal(isTenMinuteRange('10:00 AM', '10:10 AM'), true);
  assert.equal(isTenMinuteRange('10:00 AM', '10:15 AM'), false);
  assert.equal(isTenMinuteRange('11:55 PM', '12:05 AM'), false);
  assert.equal(isTenMinuteRange('invalid', '10:10 AM'), false);
});